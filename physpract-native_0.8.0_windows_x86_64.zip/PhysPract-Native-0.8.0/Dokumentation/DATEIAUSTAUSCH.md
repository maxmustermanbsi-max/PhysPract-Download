# Dateiaustausch in 0.7.0

Stand: 26.10.2026, Debian 13 / amd64. Der FKS-Austausch ist anhand des Windows-Originals
PhysPract 3.4.7b04 belegt. Eine Zusicherung für beliebige unbekannte Programmversionen folgt daraus nicht.
Android ist noch nicht gebaut oder im Dateiaustausch geprüft.

| Weg | Verhalten | Grenze |
|---|---|---|
| Original → Debian | Bestehende FKS-Dokumente mit allen fünf Modulen, mehreren Messreihen und beiden M6-Tabellen öffnen | Unterstützte Struktur und Werte werden streng geprüft; unbekannte oder beschädigte Strukturen werden abgewiesen. |
| Debian → Original | Importierte FKS-Dokumente mit geänderten Messwerten und zugeordneten Metadaten/Optionen speichern | Originalarchiv und Vergleichsbasis erforderlich; unsicher abbildbare Änderungen werden abgewiesen. |
| Debian → Debian | Vollständige PPN-Dokumente, Formatversion 2 | Optionen, Zahlentexte, Flags und native Verarbeitung bleiben erhalten; Ergebnisse werden neu berechnet. |
| Ältere Debian-Ausgaben → 0.7.0 | PPN-Versionen 1 und 2 lesen | Ohne gespeicherte FKS-Vergleichsbasis kein FKS-Rückexport; das Original erneut öffnen. |
| TSV | Messwerttabellen importieren und exportieren | Keine vollständigen Metadaten, Optionen oder Dokumentstruktur. |
| Debian ↔ Android | Noch nicht abgenommen | Ohne Android-Build und echte Dateiübertragung kein Plattformnachweis. |

## FKS öffnen, ändern und speichern

Datei → Öffnen liest `.fks` und `.ppn`. Speichern behält das aktuelle Format bei;
Speichern unter bietet beide Formate an. Neue native Dokumente verwenden PPN.
Ein bloßes Umbenennen einer PPN-Datei erzeugt kein FKS-Dokument.

Der Import bewahrt das Originalarchiv und eine interpretierte Vergleichsbasis im Dokument.
Unverändertes Speichern liefert exakt dieselben Archivbytes. Änderungen werden gezielt in die
vorhandene Originalstruktur geschrieben; unbekannte Felder bleiben erhalten. Veraltete
Originalergebnisse werden bei wissenschaftlichen Änderungen entwertet.

Zu den zugeordneten Angaben gehören Dokumentkennung, Autoren, Versuch und gemeinsamer Titel,
Messparameter und Achsenbeschriftungen, Regressionsmodelle und unterstützte Modelloptionen,
Standardunsicherheit, O1-Fokus sowie M6-Massen und -Durchmesser.
Bestehende Messreihen und beide M6-Tabellen bleiben getrennt erhalten.
Die Anzahl der Messreihen und native Zusatzfunktionen lassen sich nicht beliebig in FKS übersetzen.
Der Schreiber prüft die tatsächliche Änderung und verweigert nicht zugeordnete Zustände,
statt Optionen stillschweigend wegzulassen. Dann das vollständige Dokument als PPN speichern.

Neue Dokumente ohne importiertes FKS und ältere PPN-Dateien ohne `fksBaseline` können nicht als
FKS gespeichert werden. Nach erfolgreichem FKS-Speichern werden Originalbytes und Vergleichsbasis
auf den gespeicherten Stand aktualisiert; auch ein anschließendes PPN behält diese Herkunft.

## Wissenschaftliche Grenzen

Die native Berechnung bleibt mathematisch eigenständig. Originalergebnisse sind kein aktueller
nativer Fit; nach dem Öffnen neu berechnen. Der Logarithmus unterstützt mit `logOffset=false`
auch die Originalvariante `y=a ln(x-b)` ohne additive Konstante.

Der ursprüngliche Spline-Regler wird getrennt als `originalFksOptions.splineDampingPosition`
aufbewahrt. Sein Rohwert aus Originalfeld 23 ist **nicht** gleichbedeutend mit der nativen
Dämpfung von 0 bis 1. Die native C1-Hermite-/PCHIP-Dämpfung ist kein Nachbau dieses Originalalgorithmus.
Unveränderte Originaleinstellungen bleiben beim Tabellenrückexport erhalten; nicht zugeordnete
native Dämpfungs- oder Verarbeitungsschritte benötigen PPN.

O8 übernimmt die bekannten Wellenlängen und den Gradmodus. Das Original fragt eine feste
Glasdicke bei jeder Berechnung erneut ab, vorbelegt mit 1 mm. Eine gültige gespeicherte
Originalrechnung kann die zuletzt verwendete Dicke enthalten; sie ist kein dauerhaft gespeicherter
Vorgabewert für den nächsten Originalfit. Wissenschaftliche Änderungen bei fester, von 1 mm
abweichender Dicke werden deshalb für FKS abgewiesen. PPN erhält diese Eingabe vollständig.

## Validierung und Schutz

Dokumente sind auf 16 MiB begrenzt. Ungültige Daten und nicht sicher abbildbare Änderungen werden
vor dem Ersetzen des Ziels abgewiesen. Reguläres Speichern verwendet `QSaveFile` zum atomischen Ersetzen.
Der PPN-Schreiber erkennt die Originalsignatur `FBFK` auch hinter einer `.ppn`-Endung und
verweigert das Überschreiben eines umbenannten Originalarchivs.

Aktueller Nachweisstand: [STATUS.md](STATUS.md), [Testergebnisse 0.7.0](TESTERGEBNISSE-0.7.0.txt).
Quellbelege: [semantische Zuordnung](testprotokolle/0.7.0/fks-format/semantic-mapping.md),
[O8 und Spline](testprotokolle/0.7.0/fks-format/o8-spline-mapping.md).
Die [Testergebnisse 0.6.1](TESTERGEBNISSE-0.6.1.txt) bleiben ein historischer Nachweis für den damaligen Stand.
