# Arbeitsbeispiele

Für PhysPract Native 0.7.0. Die Beispiele zeigen native Sollwerte, keine neue Originalabnahme.
Vor jedem Beispiel Datei → Neuer Datensatz wählen, dann Datei → Auswertung einstellen.
Nach Änderungen mit Strg+F9 berechnen. Alte Ergebnisse gelten bis dahin als veraltet.

## Linear

Allgemeine Gerade wählen. Diese Tabelle ohne Kopfzeile ab der ersten X-Zelle einfügen:

```text
0	1
1	3
2	5
3	7
4	9
```

Berechnen: `y = 2x + 1`, Steigung 2, Achsenabschnitt 1, Residuen 0 bis auf Rundung.
Unter Bearbeiten Titel und Einheiten ergänzen. Als `gerade.ppn` speichern, erneut öffnen und berechnen.
Import/Export → Auswertung als PDF erzeugt den Bericht; PNG exportiert nur die Grafik.
Strg+G oder Import/Export → Grafik kopieren legt die beschriftete Grafik als Bild in die Zwischenablage.

## Nichtlinear

Parabel in Hauptform wählen. Folgende Werte einfügen:

```text
-2	3
-1	0
0	1
1	6
2	15
```

Berechnen: `y = 2x² + 3x + 1`, also `a=2`, `b=3`, `c=1`.
In Scheitelform lauten dieselben Parameter `a=2`, `b=-0,75`, `c=-0,125`.
Für andere Modelle zuerst Modell und Offsetoption einstellen, dann Aktionen → Analytisches Beispiel laden.
Die zugehörigen Gleichungen und Sollparameter stehen in [MATHEMATIK.md](MATHEMATIK.md).
Manuelle Startwerte unter Berechnungseinstellungen mit Semikolon trennen; Anzahl und Reihenfolge müssen zum Modell passen.

## Spline

Spline wählen und `(0;1)`, `(1;3)`, `(3;7)` als X/Y-Paare eingeben.
Dämpfung 0 und 151 Stützpunkte einstellen. Interpolieren ergibt `y=2x+1` über `[0;3]`.
Fadenkreuz aktivieren, Grafik anklicken und X auf 2 setzen: Y soll 5 sein.
Mit Fenster 5 und Grad 1 glätten; die Gerade bleibt bis auf Rundung erhalten.
Glättungen wirken kumulativ. Neu interpolieren setzt sie zurück; gespeicherte Schritte werden nach Wiederöffnen beim Berechnen wiederholt.

## M6

M6 wählen und Aktionen → Analytisches Beispiel laden. Beide Tabellen werden mit je 24 Kreispunkten gefüllt.
Das Beispiel schaltet Radien- und Auftreffhöhenkorrektur aus. Vor Berechnung diesen Zustand prüfen.
Sollwerte: Mittelpunkte ungefähr `(133,333333;0)` mm, Radien `66,666667` und `133,333333` mm.
Bei gleichen X-Mittelpunkten ergibt das geometrische Verhältnis ungefähr `0,5`.
Mit Massen 20 und 10 ergibt der Wägungsvergleich ebenfalls `m₂/m₁=0,5`.
Editor/Ergebnisse wechselt zur Ergebnisansicht. Unter Berechnungseinstellungen lassen sich Kreis- und
Verhältnisunsicherheiten einschalten. Die optionale Auftreffhöhenkorrektur verlangt eine gemessene
Fallhöhe vom Schwerpunkt bis zum Papier in mm; sie muss größer als beide Kugelradien sein.
Dieses ideale Beispiel enthält keine physikalischen Korrekturverschiebungen.

## O1

O1 wählen und Aktionen → Analytisches Beispiel laden. Fokusabstand auf 200 mm setzen.
Die fünf Paare entstehen aus `s=500,600,700,800,900` mm und `e=sqrt((s−200)²−40000)` mm.
Berechnen liefert in der transformierten Grafik Steigung 1 und Abschnitt −40000 mm².
Fokusausgleich aktivieren und erneut berechnen: `aF≈200 mm`, `f≈100 mm`, `d_H≈0 mm`.
Brennweite und Hauptebenenabstand werden auch bei festem Fokus aus dem physikalischen Steigung-1-Modell berechnet.
Unter Berechnungseinstellungen Standardunsicherheiten u(s), u(e) und bei festem Fokus u(aF) in mm angeben
und Parameterunsicherheiten einschalten. Der Fokusfehler gilt gemeinsam für alle Messpunkte; 0 bedeutet nicht angegeben.

## Mehrere Reihen und Datenaustausch

Über Datei → Messung hinzufügen eine weitere Reihe anlegen. Optionen und Achsentexte je Reihe prüfen.
Unter Fenster die gewünschten Reihen auswählen und berechnen; gemeinsame Grafiken verwenden sichtbare berechnete Reihen desselben Moduls.
PPN erhält das Dokument. TSV überträgt Tabellenwerte, keine vollständigen Optionen oder Verarbeitungshistorie.
Für den FKS-Rückexport eine bestehende Originaldatei öffnen, einen Messwert ändern und über
Speichern unter eine neue `.fks`-Kopie anlegen. Die Kopie erneut öffnen und Daten/Optionen prüfen.
Mehrere bestehende Messreihen und beide M6-Tabellen bleiben getrennt. Nicht zugeordnete native
Änderungen werden vor dem Schreiben abgewiesen; dann PPN verwenden. Grenzen zu Spline-Dämpfung,
O8-Dicke und Originalversion stehen in [DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md).
