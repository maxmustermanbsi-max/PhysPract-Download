# Mathematische Referenz der nativen Implementierung

Stand: 0.7.0. Maßgeblich sind `src/core.cpp`, `src/core.h` und die wissenschaftlichen Tests.
Diese Beschreibung dokumentiert die native wissenschaftliche Methode. Originalfehler und Rundungsverluste werden nicht nachgebildet.
Nur aktive Messpunkte gehen in die Rechnung ein. σY-Spalte und Fehlerbalken gewichten den Fit nicht.

## Regressionen und Parameter

| Modellkennung | Gleichung | Parameterreihenfolge / Grenze |
|---|---|---|
| ordinary | y=a·x+b | a, b; mindestens 3 aktive Punkte |
| origin | y=a·x | a; mindestens 2 aktive Punkte |
| orthogonal | y=a·x+b | a, b; orthogonale Abstände, keine senkrechte Gerade |
| parabola | y=a·x²+b·x+c | a, b, c |
| parabola mit vertex | y=a·(x−b)²+c | a, b, c; b ist Scheitel-X |
| exponential | y=a·exp(b·x)+c | a, b; c nur bei Offset |
| hyperbola | y=a/(x−b)+c | a, b, c; x≠b |
| logarithm | y=a·ln(x−b)+c bzw. y=a·ln(x−b) | Mit logOffset=true (Standard): a, b, c; false: a, b; x>b |
| tangent | y=a·tan(b·x+c)+d | a, b, c; d nur bei Offset; Pole ausgeschlossen |

Nichtlinear werden mehr aktive Punkte als freie Parameter benötigt. Startwerte folgen der Tabellenreihenfolge.
Die Minimierung erfolgt direkt über die Summe quadrierter Y-Abweichungen mit skaliertem Levenberg-Marquardt.
Tangens verwendet im Funktionsargument Bogenmaß; die Gradoption gehört zu O8.
Achsenbeschriftungen rechnen Messwerte nicht in andere Einheiten um.
Für `y=a·x+b` hat a die Einheit Y/X, b die Einheit Y. Andere Parameter folgen aus ihrer Gleichung.

## O8

Mit Winkel `α=(x−α₀)` in rad gilt:

`y = 2d/λ · (sqrt(n²−sin²(α)) − cos(α) − n + 1)`.

`n>1`, `d>0`, `λ>0`; d und λ in mm. Standard: λ=0,0006328 mm und d=1 mm.
Die Gradoption rechnet x und α₀ vor der Auswertung in rad um.
Parameterfolge: n, optional d bei freier Dicke, optional α₀ bei freiem Winkelnullpunkt.
Bei festem Nullpunkt gilt α₀=0. Die vollständige Originalabnahme der Optionen steht aus.

## Identifizierbarkeit nichtlinearer Parameter

Nichtlineare Ergebnisse werden nur ausgegeben, wenn die Messwerte die Parameter lokal numerisch
bestimmen. Die Parabel prüft zunächst ihre zentrierte, skalierte Designmatrix. Alle nichtlinearen
Modelle prüfen am gefundenen Ergebnis einen analytischen Jacobian, auch bei verschwindenden Residuen.
Spaltennormierung entfernt die unmittelbare Abhängigkeit von Parametereinheiten; eine SVD mit relativer
Schwelle `64·eps·max(N,k)` weist Nullspalten und numerisch abhängige Parameter zurück.
Dies prüft lokale Identifizierbarkeit in Rechengenauigkeit, keine globale Eindeutigkeit periodischer Modelle.
Sehr schlecht konditionierte Daten können deshalb mit einer erklärenden Fehlermeldung abgewiesen werden.
Die gleiche Prüfung gilt für Unsicherheitsrefits; ein gescheiterter Refit erzeugt keine scheinbar sicheren ±0.
Exponential-Startwerte verwenden die kleinsten und größten X-Werte; wiederholte Endpunkte führen nicht
mehr zu einer Division durch null allein aufgrund der Tabellenreihenfolge.

## Residuen und Unsicherheiten

Residuum: `rᵢ=yᵢ−f(xᵢ)`. Reststreuung: `sqrt(sum(rᵢ²)/(N−k))` bei N>k,
wobei k die Zahl der Fitparameter ist. Korrelation ist der Pearson-Koeffizient der aktiven X/Y-Paare;
bei fehlender Streuung wird im Statistikhelfer 0 ausgegeben.
Neue Originalreferenz: Bei der Ursprungsgeraden zeigt das Original stattdessen den unzentrierten
Wert `sum(xᵢyᵢ)/sqrt(sum(xᵢ²)·sum(yᵢ²))` gemäß Linreg.pdf, Gl. (2.7).
Für X=[−1,0,1], Y=[2,1,6] ergibt dies 0,44173, während die native Pearson-Ausgabe 0,75593 ist.
Diese nachgewiesene Abweichung wurde in diesem Referenzlauf noch nicht im Produktcode geändert.

OLS verwendet die Reststreuung oder manuelles σ. Für die allgemeine Gerade gelten
`u(a)=σ/sqrt(Sxx)` und `u(b)=σ·sqrt(1/N+x̄²/Sxx)`, mit `Sxx=sum((xᵢ−x̄)²)`.
Für die Ursprungsgerade ist `Sxx=sum(xᵢ²)`; nur u(a) wird ausgegeben.
Diese Werte sind Standardunsicherheiten ohne Student-t-Faktor. Die genaue Original-Konfidenzregel ist nicht bestätigt.

Optionale orthogonale Unsicherheiten verwenden Gauß-Fortpflanzung nach den in der lokalen Originalhilfe
referenzierten Gleichungen 3.9–3.15 von Linreg.pdf. Manuelles σ gilt radial.
Nichtlineare Unsicherheiten entstehen durch einzelne, alternierend mit +σ bzw. −σ veränderte Y-Werte,
jeweilige vollständige Wiederanpassung und quadratische Summation der Parameteränderungen.
Das Verfahren folgt dem Ansatz der O8-Hilfe und ist für die anderen Modelle vorläufig.
Bei fehlender Konvergenz der Fehlerrechnung werden keine entsprechenden ±-Werte ausgegeben.

## Spline und Digitalisierung

Natürlicher kubischer Spline: zweite Ableitung an beiden Randpunkten null. Mindestens drei verschiedene X-Werte;
die Implementierung sortiert nach X. 3 bis 100000 äquidistante Ausgabestützpunkte.
Dämpfung D liegt in `[0;1]`. Der natürliche Spline wird bei D=0 beibehalten. Bei D>0 werden
seine Knotensteigungen mit formtreuen PCHIP-Steigungen gemischt und kubische Hermite-Teilstücke ausgewertet.
Gemeinsame Knotensteigungen erhalten die stetige erste Ableitung für jedes D. Bei D=1 verhindern
gewichtete harmonische Mittel und Endpunktbegrenzer zusätzliche Überschwinger innerhalb der Intervalle.
Ungleiche X-Abstände, Plateaus und Richtungswechsel werden berücksichtigt. Für Zwischenwerte ist
Formtreue nicht garantiert; die zweite Ableitung muss dann ebenfalls nicht stetig sein.
Dies ist eine begründete native Methode, keine Nachbildung der empirischen Original-Reglerskala.

Glättung passt lokal ein Polynom vom Grad 1 oder 2 über 5, 7, 9 oder 11 Ausgabestützpunkte an.
Am Rand wird das Fenster einseitig verschoben. Wiederholungen wirken auf die letzte Kurve.
Digitalisierung interpoliert linear zwischen den gespeicherten Kurvenstützpunkten; außerhalb des Stützbereichs erfolgt ein Fehler.

## M6

Je Tabelle mindestens vier nicht kollineare aktive Punkte. Ein algebraischer Kreisfit liefert Startwerte;
der anschließende geometrische Fit minimiert radiale Abstände mit analytischen Ableitungen.
Koordinaten, Radien und Kugeldurchmesser werden in mm verwendet. Massen müssen dieselbe Einheit besitzen.

Das geometrische Massenverhältnis lautet `μ=m₂/m₁=r₁/(r₂−Δx₀)`.
Die optionale Stoßpunkt-Radienkorrektur berücksichtigt Kugeldurchmesser und wird iteriert;
die interne Stoßpunktsuche nutzt eine geklammerte Bisektion. Details stehen im lokalen Originalanhang AuswtgM6.pdf.
Der vollständige Originalvergleich ist offen.

Die optionale Auftreffhöhenkorrektur verwendet die ausdrücklich gemessene Höhe h₀ vom Schwerpunkt
bis zum Papier. Sie verlangt `h₀ > max(R₁,R₂)` und streckt den Flugvektor jeder Kugel um
`kᵢ=1+Rᵢ/[2(h₀−Rᵢ)]` nach der Stoßpunktreduktion. Beide Korrekturen und der aus Kreis 2 bestimmte
Flugursprung werden gemeinsam iteriert. Es gibt keine stillschweigende Standardfallhöhe.

Unsicherheiten der sechs Kreisparameter und des geometrischen μ entstehen aus zentralen ±sᵣ-Variationen
jedes radialen Rohmesswerts. Jede Variante durchläuft die gesamte aktive Korrektur- und Fitkette erneut.
Die Differenzen aller sieben Ergebnisparameter werden direkt quadratisch summiert; ihre gemeinsame
Abhängigkeit bleibt damit auch in μ erhalten. Näherungsweise unabhängiges radiales Messrauschen wird
angenommen: sᵣ stammt aus den finalen radialen Residuen mit N−3 Freiheitsgraden, die Variationsrichtung
aus dem unkorrigierten Kreisfit. Vor der Rohvariation wird die durch die Höhenkorrektur verursachte
Streckung zurückgerechnet: σᵣ,roh=σᵣ,final/kᵢ. Bei kombinierter Stoßpunktkorrektur bleibt die aus
Residuen geschätzte radiale Rauschskala eine modellbasierte Näherung. Durchmesser und Fallhöhe gelten als feste Eingaben. Eine Wägungsunsicherheit
wird ohne entsprechende Eingaben nicht erfunden. Bei fehlgeschlagener Fehlerrechnung bleiben die Fitwerte
erhalten, sämtliche ±-Werte entfallen und ein sichtbarer Hinweis erklärt den Grund.

## O1

Eingaben s und e in mm. Transformation: `X=(s−aF)²`, `Y=e²`, jeweils in mm².
Eine orthogonale Gerade `Y=a·X+b` dient als Diagnosefit. Der optionale Fokusausgleich bestimmt aF
über gleiche zentrierte X/Y-Quadratsummen und wählt den Zweig mit positiver Steigung eins.

Das physikalische Besselmodell besitzt Steigung eins. Für festen wie angepassten Fokus gelten deshalb
`f=½·sqrt(mean((s−aF)²−e²))` und `d_H=aF−2f`, jeweils in mm. Der Mittelwert unter der Wurzel muss
positiv sein. Bei festem Fokus und Diagnoseanstieg a≠1 wird keine willkürliche Ableitung aus dem freien
Achsenabschnitt oder dessen Nullstelle gewählt. Der Diagnoseanstieg hilft, die Modellkonsistenz zu beurteilen.

Optionale Standardunsicherheiten u(s), u(e) und bei festem Fokus u(aF) werden in mm angegeben.
Null bedeutet nicht angegeben. s und e gelten als unabhängig je Messpunkt; ein gemessener Fokus ist
für alle Punkte dieselbe gemeinsame Eingangsgröße. Zentrale ±σ-Variationen wiederholen den vollständigen
Schätzer einschließlich einer aktiven Fokusbestimmung. Differenzen der fünf Parameter a,b,aF,f,d_H
werden gemeinsam ausgewertet, sodass die Fokuskovarianz insbesondere in d_H erhalten bleibt.
Bei angepasst bestimmtem Fokus ist dessen Startwert keine zusätzliche unsichere Messgröße.
Das Verfahren ist eine numerische Fortpflanzung erster Ordnung, kein exaktes Konfidenzintervall.

## Belege

[Status](STATUS.md), [Originalinventar](../archiv/2026-10-24/AUSWERTUNG_INVENTAR.md),
[Testfälle](tests/core_tests.cpp), [unabhängige Referenzen](tests/independent_references.py).
Lokale Originalhilfe und Praktikumsunterlagen sind Referenzquellen und werden nicht mit dem Paket ausgeliefert.
