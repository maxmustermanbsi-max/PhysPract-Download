# Vergleich mit dem Windows-Original

Historischer Referenzbericht vor den Funktionsverbesserungen von 0.6.0. Die Messbelege bleiben erhalten.
Aktueller Maßstab ist [FUNKTIONSABNAHME.md](FUNKTIONSABNAHME.md); bekannte Originalfehler und Rundungsverluste
werden nicht nachgebaut. Aussagen über unveränderten Produktcode beziehen sich auf die damalige Referenzphase.

Stand: 24.10.2026. Untersucht wird PhysPract 3.4.7 b04 unter Wine mit Open Computer Use.
Die direkte Bedienung erfolgt durch Luna-Agenten. Dieser Bericht fasst neue Einzelbelege zusammen;
er ist keine vollständige Originalabnahme und keine neue Produktfreigabe.

## Neue lineare Referenzen

Alle folgenden Fälle verwenden X = [−1, 0, 1], Y = [2, 1, 6].
Die Werte in der Tabelle sind Originalanzeigen; zusätzliche Nachkommastellen werden nicht erfunden.

| Modell / Messabweichung | Originalanzeige | Einordnung |
|---|---|---|
| Allgemeine Gerade, Standard | a=2 ±3,19; b=3 ±2,6; σ=2,45; r=0,75593 | Koeffizienten und Reststreuung unabhängig bestätigt. Der gezielte Fall stützt zentrale Student-t-Konfidenz 68,3 % gegenüber dem exakten zentralen 1σ-Niveau. |
| Allgemeine Gerade, manuell σ=1 | a=2 ±0,707; b=3 ±0,577; x₀=−1,5 ±0,604; r=0,75593 | Standardunsicherheiten ohne zusätzlichen Student-t-Faktor passen auf Anzeigepräzision. |
| Ursprungsgerade, Standard | a=2 ±3,79; σ-Feld=4,062; r=0,44173 | Die genaue Standardfehler-/Rundungsregel bleibt offen. |
| Ursprungsgerade, manuell σ=1 | a=2 ±0,707; r=0,44173 | Parameterfehler und unzentrierte Korrelation stimmen mit den unabhängigen Sollwerten überein. |
| Orthogonale Gerade, Standard | a=3,3028 ±4,86; b=3 ±2,99; x₀=−0,90833 ±1,61; σ-Feld=0,8882; r=0,75593 | Koeffizienten und radiale Reststreuung bestätigt; Standardfehler sind gegenüber den Gauß-Standardunsicherheiten vergrößert. |
| Orthogonale Gerade, manuell σ=1 | a=3,3028 ±2,98; b=3 ±1,83; x₀=−0,90833 ±0,989; r=0,75593 | Radiale Messabweichung mit der Fortpflanzung nach Linreg.pdf passt für diesen Fall. |

Die vollständigen Eingaben, Optionen und PNG-Belege stehen in den
[Livebeobachtungen](../testdaten/referenz-2026-10-24-neustart/beobachtungen.json).
Die unabhängigen Rechnungen stehen im [allgemeinen Linearvergleich](../testdaten/referenz-2026-10-24-neustart/linear-student-vergleich.json)
und im [Variantenvergleich](../testdaten/referenz-2026-10-24-neustart/linear-varianten-soll.json).

## Belegte Unterschiede und verbleibende Fragen

- **Korrelation der Ursprungsgeraden:** Das Original verwendet den unzentrierten Ausdruck aus Linreg.pdf, Gl. (2.7).
  Er ergibt hier 0,44173. Die native Statistik verwendet bisher den zentrierten Pearson-Wert 0,75593.
- **Standardmodus:** Eine einzige universelle Quantil-/Rundungsregel ist noch nicht belegt.
  Beispielsweise ergibt das volle Student-Quantil mit p=0,683 und zwei Freiheitsgraden für den Ursprungsfit
  auf drei signifikante Stellen 3,80; das Original zeigt 3,79. Beim orthogonalen Nullstellenfehler ergibt
  der entsprechende volle Quantilansatz 1,62 statt der beobachteten 1,61.
  Die native Anwendung gibt weiterhin ausdrücklich unskalierte Standardunsicherheiten aus.
- **Spline-Dämpfung:** Die Originalhilfe beschreibt kubische Teilfunktionen mit stetiger erster Ableitung
  und geänderten Endanstiegen. Die native Mischung aus natürlichem Spline und linearer Interpolation
  erfüllt diese Eigenschaft im Allgemeinen nicht. Neue Digitalisierungen widersprechen auch numerisch
  dieser Mischung. Die genaue Originalkennlinie und Randbedingungen fehlen weiterhin.
- **M6:** Ein neuer Vollkreisversuch mit zwölf Punkten je Tabelle blieb wieder bei
  „Fehlerrechnung (Kreis 2): 7.7%“ stehen. Der Lauf wurde abgebrochen; kein erfolgreicher Original-Kreisfit.
- **Tangens:** Die vorbereiteten fünf bzw. sieben Punkte wurden bei der automatischen Startwertsuche abgewiesen.
  Das ist ein belegter Fehlerpfad. Eine anschließende fallende Elfpunktreihe y=3·tan(1−0,08x), x=0…10,
  wurde erfolgreich automatisch angepasst. Damit hängt die Startwertsuche nachweislich von der Reihe ab;
  der vollständige Options- und Unsicherheitsvergleich bleibt offen.

Produktcode und Produktbinärdatei wurden durch diese Referenzarbeit nicht geändert.

## Nichtlineare und weitere Prüfungen

| Fall | Originalanzeige | Aussage und Grenze |
|---|---|---|
| Exponentialfunktion mit Offset, elf Punkte, y=3·exp(−0,4x)+2 | a=3 ±3,1E−6; b=−0,4 ±9,79E−7; c=2 ±1,67E−6; σ=2,8956E−6 | Erfolgreicher Fit; Koeffizienten stimmen auf Anzeigepräzision mit den Sollwerten überein. Die kleinen Restfehler der synthetischen Reihe belegen keine allgemeine Unsicherheitsregel. |
| Exponentielles Abklingen ohne Offset, elf verrauschte Punkte, drei negative Y | a=3,04622 ±0,0326; b=−0,814676 ±0,0179; σ=0,031392 | Original akzeptiert negative beobachtete Y. Unabhängiger direkter Y-Ausgleich ergibt a=3,0462167390, b=−0,8146770533 und σ≈0,0313922. Abweichung von b rund 1,05E−6; a und σ stimmen auf Anzeigepräzision. Der Befund stützt direkte Anpassung im Y-Raum. |
| Fallender Tangens ohne Offset, elf Punkte, y=3·tan(1−0,08x) | a=2,99967 ±1,92E−4; b=−0,080002 ±1,37E−6; c=1,00005 ±3,23E−5; σ=3,3461E−5 | Automatische Startwertsuche und Fit erfolgreich. Parameter liegen nahe dem Soll; Fehlerkonvention noch nicht abgenommen. |
| Fallender Tangens mit Offset, dieselben x, y=3·tan(1−0,08x)−0,2 | a=3,00016 ±1,46E−4; b=−0,0799834 ±8,29E−6; c=1,00004 ±6,6E−6; d=−0,200653 ±3,09E−4; σ=1,0266E−5 | Auch die Offsetoption liefert einen erfolgreichen Fit. Gerundete Werte und kleine Reststreuung sind keine vollständige Unsicherheitsabnahme. |
| O8, sieben Winkel −60° bis +60°, feste Dicke 1 mm, Sollwellenlänge 520 nm | n=1,5 ±1,33E−7; α₀=0,572962° ±3,21E−6; d=0,001 ±0; σ=1,6344E−4 | Erster erfolgreicher O8-Fit. Sollwinkeloffset 0,572957795130823°; absolute Abweichung rund 4,205E−6°. Die anschließende freie Anpassung bestätigt die Wellenlängenanzeige 5,2E−7; weitere Optionen bleiben offen. |
| O8, dieselben sieben Punkte, Glasdicke anpassen | d=0,0010002 ±4,98E−8; n=1,49981 ±5,11E−5; α₀=0,572938° ±1,82E−4; λ=5,2E−7 ±0; σ=0,0090873 | Freier Fit mit Wellenlänge 520 nm belegt; d und λ werden in Metern interpretiert. Gerundete Fitparameter weichen vom synthetischen Soll ab. Weitere Optionen und Fehlerkonventionen bleiben offen. |

Die freie Dickenanzeige wurde im vergrößerten Ausschnitt von `nlr-o8-free-d-verified-output.png` geprüft.
Die erste Ablesung 0,001002 wurde verworfen; der Screenshot zeigt 0,0010002.
Die angezeigten Parameterunsicherheiten sind Originalausgaben, keine festgelegten Akzeptanztoleranzen.
Insbesondere liegt die O8-Winkelabweichung geringfügig über der angezeigten Unsicherheit.
Eine Fehlerrechnung oder universelle Konvergenzgenauigkeit folgt daraus nicht.

Eine unabhängige [Residualprüfung](../testdaten/referenz-2026-10-24-neustart/nlr-numerikvergleich.json)
liefert an den Sollparametern für die gespeicherten Exponentialeingaben eine Reststreuung von rund
3,43E−15 und für O8 mit fester Dicke rund 1,86E−13. Die Originalanzeigen liegen deutlich darüber.
Damit sind die Originalresultate erfolgreiche numerische Annäherungen; ihre kleinen Unsicherheiten
sind noch keine unabhängig bestätigte Fehlerkonvention. Auch der separate native Exponentialfit
liefert eine andere numerische Reststreuung. Identische Anzeigeparameter beweisen keine vollständige Rechenparität.

Ein zusätzlicher Vergleich rundet die eingegebenen X/Y-Werte vor dem Fit auf sechs signifikante Stellen.
Eine neue O1-Exportprüfung bestätigt diese Eingaberundung für den getesteten O1-Ablauf.
Für NLR bleibt dieselbe Regel eine gesondert zu prüfende Hypothese; sie erklärt wesentliche Unterschiede:
O8 mit fester Dicke ergibt dann σ≈0,000163440002 und α₀≈0,572961842°, passend zu beiden Originalanzeigen.
Beim verrauschten exponentiellen Abklingen runden auch b≈−0,81467593449 und σ≈0,03139204893 zur Anzeige.
Beim Exponentialfit mit Offset verbleiben etwa 0,0621 % Unterschied in σ. Die freien O8- und Tangensfits
werden durch Quantisierung allein weiterhin nicht vollständig erklärt. Die ursprünglichen Vergleiche
gegen ungerundete Eingaben bleiben erhalten; sie beweisen für sich keinen Fehler des Originalalgorithmus.

Neue nichtlineare Einzelbelege werden separat in den
[NLR-Beobachtungen](../testdaten/referenz-2026-10-24-neustart/nlr-beobachtungen.json) geführt.
Die [O8-Sollwerte](../testdaten/referenz-2026-10-24-neustart/o8-sollwerte.json) unterscheiden 520 nm und 632,8 nm
sowie Grad und rad. Vor einem Vergleich muss die tatsächliche Originalkonfiguration bestätigt werden.
Alle offenen Bereiche und historischen Nachweise bleiben in der [Abnahmematrix](../ABNAHMEMATRIX.md)
und ihrer [Fallabdeckung](../testdaten/referenz-2026-10-24-neustart/abdeckung.json) nachvollziehbar.
Für den Splinevergleich liegen [unabhängige Vergleichskandidaten und Ablesestellen](../testdaten/referenz-2026-10-24-neustart/spline-pruefblock.json) vor.
Diese Zahlen sind keine bereits gemessenen Originalwerte.

Der erste neue [Splineblock](../testdaten/referenz-2026-10-24-neustart/spline-beobachtungen.json)
enthält sieben ungleichmäßig verteilte, gekrümmte Eingabepunkte auf x=0…4.
Bei minimaler Dämpfung und 150 Ausgabepunkten wurden neun X-Werte direkt im Digitalisierdialog eingegeben.
Die Originalanzeigen umfassen beide Datenränder; sie ergeben beispielsweise y(0,2)=0,19511,
y(1,4)=1,009 und y(3,95)=−0,74474. Der Regler besitzt keine sichtbare Zahlenanzeige.
Die genaue Randkonvention und die Auswertung zwischen Ausgabepunkten bleiben noch zu bestimmen.

Nach frischer Interpolation bei mittlerer und maximaler Reglerstellung wurden dieselben neun Stellen abgelesen:

| X | Minimum | Reglermitte | Maximum |
|---|---|---|---|
| 0,2 | 0,19511 | 0,19511 | 0,19511 |
| 0,8 | 0,72381 | 0,73241 | 0,7401 |
| 1,4 | 1,009 | 0,99633 | 0,98996 |
| 2,2 | 0,81228 | 0,80992 | 0,81392 |
| 3,95 | −0,74474 | −0,74473 | −0,74473 |

Die Pixelposition der Reglermitte ist kein belegter numerischer Dämpfungswert 0,5.
Die Beobachtungen zeigen eine Änderung im Inneren bei nahezu unveränderten randnahen Werten.
Ein unabhängiger Modellvergleich und die Glättungsvarianten bleiben getrennte Prüfschritte.

Der [unabhängige Splinevergleich](../testdaten/referenz-2026-10-24-neustart/spline-vergleich.json)
verwirft für diese Reihe die natürliche kubische Interpolation als Erklärung der Minimalstellung:
maximale Abweichung rund 0,01135, deutlich größer als die protokollierte Anzeigeauflösung.
Eine Digitalisierung des 150-Punkte-Polygons erklärt die Differenz ebenfalls nicht.
Auch die getesteten Standardränder „not-a-knot“, horizontale, Sekanten- und quadratische Randanstiege
passen nicht allen neun Ablesungen.

Bei x=0,8 liefert der natürliche Spline rund 0,717444 und die lineare Interpolation rund 0,696443.
Jede native Mischung mit D zwischen 0 und 1 liegt zwischen diesen Zahlen; das Original zeigt bereits
bei Minimalstellung 0,72381. Damit passt diese Modellfamilie unabhängig von der unbekannten Reglerskala
nicht zum beobachteten Original. Die exakte Originalformel ist dadurch noch nicht bestimmt.

Alle acht Glättungsvarianten wurden bei 50 Ausgabepunkten und minimaler Dämpfung jeweils nach
frischer Interpolation geprüft. Die fünf Ablesestellen waren x=0; 0,2; 1,4; 3,95; 4.
Beispiele aus diesem Block:

| Glättung | y(0) | y(1,4) | y(4) |
|---|---|---|---|
| Ohne Glättung | 0,03 | 1,0086 | −0,78568 |
| Linear, 5 Punkte | 0,029859 | 1,0019 | −0,78671 |
| Linear, 7 Punkte | 0,028967 | 0,99529 | −0,78821 |
| Linear, 9 Punkte | 0,025191 | 0,98643 | −0,79033 |
| Linear, 11 Punkte | 0,021992 | 0,97535 | −0,79305 |
| Parabolisch, 5 Punkte | 0,030004 | 1,0086 | −0,78568 |
| Parabolisch, 7 Punkte | 0,030442 | 1,0086 | −0,78568 |
| Parabolisch, 9 Punkte | 0,031907 | 1,0086 | −0,78573 |
| Parabolisch, 11 Punkte | 0,031058 | 1,0086 | −0,78578 |

Ein zweiter linearer Fünfpunktdurchlauf ohne neue Interpolation verändert die Kurve erneut:
y(1,4) sinkt von 1,0019 auf 0,99529. Eine neue Interpolation stellt die fünf Ausgangsablesungen wieder her.
Damit sind kumulative Glättung und Rücksetzen im Original beobachtet; kurze und ungültige Reihen bleiben offen.

Nach Fokus auf den Dämpfungsregler und Home-Taste wurden 50 und 500 Ausgabepunkte verglichen.
Bei x=0,8 lauten die Anzeigen 0,72336 beziehungsweise 0,72386; bei x=1,4 lauten sie 1,0086 und 1,009.
Die Stützpunktzahl beeinflusst somit die digitalisierte Ausgabe. Die exakte Auswerteregel ist noch nicht bewiesen.
Der numerische Dämpfungswert der Minimalstellung bleibt mangels Zahlenanzeige unbekannt.

Im Abszissendialog verwirft Escape eine geänderte Eingabe ohne neue Terminalzeile.
X=−0,1 wird mit „Eingegebener Wert nicht im Bereich von 0 bis 4“ abgewiesen; kein Extrapolat entsteht.
Anschließend wurde zum Tabelleneditor zurückgekehrt. Das sind neue Teilbelege, keine vollständige Bedienabnahme.

Ein [modellabhängiger Glättungsvergleich](../testdaten/referenz-2026-10-24-neustart/spline-glaettung-vergleich.json)
rekonstruiert zunächst eine Hermite-Kurve aus den Originalablesungen und wendet darauf lokale lineare bzw.
quadratische Fensterpolynome an. Unter fortgepflanzter Ableseunsicherheit passen acht von neun Glättungsfällen.
Offen bleibt unter anderem der parabolische Siebenpunktfall bei x=4 mit einer Abweichung von rund 2,065E−5.
Kurvenhypothese und Glättungsregel sind dadurch nicht unabhängig voneinander bewiesen.

## Neue O1-Referenzen

Die [O1-Livebeobachtungen](../testdaten/referenz-2026-10-24-neustart/o1-m6-beobachtungen.json)
verwenden fünf s/e-Paare aus dem vorbereiteten Besselfall mit f=50 mm, dH=10 mm und aF=110 mm.
Das Original zeigt die transformierten Achsen (s−aF)² und e² in mm². Neue feste Fokusfälle:

| Fokus | a | b / mm² | x₀ / mm² | σ-Feld |
|---|---|---|---|---|
| 110 mm | 1 ±7,88E−7 | −10000 ±0,0312 | 10000 ±0,0321 | 0,021347 |
| 100 mm | 0,94499 ±0,00266 | −11619 ±116 | 12295 ±128 | 78,135 |
| Automatisch angepasst, Endanzeige 110 mm | 1 ±7,61E−7 | −9999,9 ±0,0301 | 9999,9 ±0,031 | 0,020605 |

Der [unabhängige Vergleich](../testdaten/referenz-2026-10-24-neustart/o1-vergleich.json)
liefert bei voller Eingabepräzision für 110 mm eine nahezu verschwindende Reststreuung.
Werden die e-Eingaben dagegen auf sechs signifikante Stellen gerundet, entstehen die sichtbaren Werte
45,8258; 97,9796; 137,477; 173,205; 207,123. Damit ergeben sich σ≈0,021346875 und σ≈78,134837,
also beide Originalanzeigen. Runden auf vier Dezimalstellen erklärt den ersten Wert nicht.
Der neue Originalexport `ref-o1-precision-20261024.fks` enthält tatsächlich genau diese gerundeten
e-Werte als Binärzahlen. Damit ist die effektive Eingabepräzision für diesen O1-Ablauf bestätigt.
Die ursprünglichen vollständigen Eingaben bleiben als Versuchsprotokoll erhalten.

Das Original zeigt in diesen Fällen a, b, x₀ und Korrelation, aber keine Brennweite f oder Hauptebenendistanz dH.
Die beiden theoretischen Brennweitenableitungen bei falschem Fokus lassen sich daher anhand dieser Anzeige
nicht unterscheiden. Der automatische Fokusausgleich liefert die Anzeige 110 mm und das Zusatzfeld
1,3E−4. Obwohl zuvor 100 eingegeben wurde, zeigte das Feld nach dem Zeichnen und vor dem Fit 0;
ein tatsächlicher Start bei 100 ist daher nicht belegt. Weitere Startwerte und Unsicherheitsfälle bleiben offen.

## Vorhandene FKS-Archive

Eine [Bestandsinventur](../testdaten/referenz-2026-10-24-neustart/fks-bestandsinventur.json)
prüft zehn bereits vorhandene Originalarchive im Wine-Präfix mit dem unveränderten nativen Tabellenleser.
Alle zehn Tabellenextraktionen gelingen: sechs nichtlineare Archive sowie je ein lineares, Spline-, O1-
und M6-Archiv. M6 enthält zwei Tabellen mit jeweils fünf Zeilen. Die Quelldateien bleiben hashgleich.
Das ist kein neuer Export und bestätigt keine vollständige Übernahme der Modelloptionen oder Metadaten.
Die Dateinamen belegen keine Modellreferenz: Mehrere verschieden benannte nichtlineare Archive enthalten
dieselbe Fünfpunktreihe 3·2ˣ. Maßgeblich sind die ausgelesenen Inhalte und dokumentierten Optionen.
Vor einem weiteren Exportversuch wurde die aktuelle Original-Hauptdatei separat bytegleich gesichert;
der [Bestandsnachweis](../testdaten/referenz-2026-10-24-neustart/fks-bestand-vor-neuem-export.json) hält alle Prüfsummen fest.

Der neue [O1-Originalexport](../testdaten/referenz-2026-10-24-neustart/ref-o1-precision-20261024.fks)
wurde zunächst auf dem Desktop gespeichert und anschließend bytegleich in den Referenzordner kopiert.
Die [Inspektion](../testdaten/referenz-2026-10-24-neustart/o1-neuer-fks-export-inspektion.json)
liest fünf O1-Zeilen mit den sechs signifikanten Eingabestellen; SHA-256:
`3e10fad7daefc4e358106b6c5b120c3a61e7453e694f7563ef440e08fdd608c6`.
Damit liegt erstmals in diesem neuen Referenzlauf ein erfolgreicher Export mit anschließender nativer
Tabellenextraktion vor. Optionen, Metadaten und ein beidseitiger Rückaustausch sind weiterhin nicht abgenommen.

## Betriebsdiagnose

Der GUI-Freeze wurde durch erschöpfte Dateideskriptorlimits eingegrenzt und entschärft.
Ein privater OCU-Client verhindert neue AT-SPI-P2P-Verbindungen. Kontrollierte Lese- und Eingabeblöcke
ließen die Zahl bereits verlorener Prozessreferenzen unverändert. Der Nutzer bestätigte wieder bedienbare GUI.
Ein späterer blockierter Exportversuch wurde auf Nutzerwunsch durch einen gezielten Original-Neustart beendet.
Die neue Originalinstanz reagierte auf das Datei-Menü. Details: [OCU-Reparaturbericht](../tools/open-computer-use-repair/README.md).
