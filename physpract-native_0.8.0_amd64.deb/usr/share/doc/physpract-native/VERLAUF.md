# Projektverlauf

Stand: 30.10.2026. Historische Aufträge bleiben unten dokumentiert.

| Stand | Wesentliche Änderungen |
|---|---|
| 0.8.0 | LaTeX-Tabellen, skalierte x/y-Berichtstabellen nebeneinander, Zellrechnungen, Formelumrechnung mit Rohwerten und vollständige Projekte. |
| 0.7.1 | Zusätzliche Fenster mit einzelnen oder mehreren Datensätzen und gemeinsamer Wiederherstellung. |
| 0.7.0 | Quelltreuer FKS-Rückaustausch und optionaler Logarithmus ohne additive Konstante. |
| 0.6.1 | NLR-Identifizierbarkeit, Exponential-Startwerte, vollständige O1-/M6-Exportoptionen. |
| 0.6.0 | Skalenstabile orthogonale Regression, C1-Splines und vollständige O1-/M6-Fehlerrechnung. |
| 0.1.0–0.5.0 | Frühere Entwicklungsstände; Einzelheiten im Archiv und in den jeweiligen Prüfprotokollen. |

## Aktueller Nachweisstand

Maßgeblich sind [STATUS.md](native/STATUS.md) und [das 0.8.0-Protokoll](native/TESTERGEBNISSE-0.8.0.txt).
Aktuelle und historische Paketnachweise werden getrennt ausgewiesen. Android bleibt ungebaut.

## Dokumentationsbereinigung

Am 24.10.2026 wurden historische Sammeldokumente bytegleich archiviert und durch eindeutige Einstiege ersetzt.
Ältere Debian-Pakete wurden ins Archiv verschoben. Referenzdaten, Originaldateien, Testprotokolle,
Buildumgebung und Wine-Präfixe wurden erhalten. Anwendungscode und Versionsnummer wurden nicht geändert.
Neue Anleitungen beschreiben den vorhandenen Code; sie erklären keine offene Abnahme für bestanden.
Die Projektlizenz bleibt eine Entscheidung der Rechteinhaber und wurde nicht erfunden.

Nachweis der Bereinigung: [Prüfbericht](native/testprotokolle/dokumentation-2026-10-24/pruefung.md).

Auf erneuten Nutzerauftrag wurde die Originalreferenzarbeit mit Luna-Desktopbedienung wieder aufgenommen.
Anleitungen wurden textuell ausgewertet. Ein vertauschtes Verhältnis im alten M6-Sollfall wurde im Generator
und dessen JSON-Ausgabe korrigiert: μ=m₂/m₁=0,5; das inverse Verhältnis bleibt explizit 2.
Neue Einzelbelege werden unter `testdaten/referenz-2026-10-24-neustart/` geführt.

Ein erneuter GUI-Freeze wurde auf ausgeschöpfte Dateideskriptorlimits eingegrenzt.
Nach temporärer Limitanhebung bestätigte der Nutzer die Bedienbarkeit. Ein privater OCU-Clientfix
verhindert neue AT-SPI-P2P-Verbindungen; nach fünf Leseaufrufen und einem Eingabeblock blieb
die pidfd-Zahl in drei Desktopprozessen unverändert. Systembibliotheken wurden nicht ersetzt.
Der neue Linearvergleich stützt Student-t mit zentralen68,3% im Standardmodus; manuellesSigma1
liefert die erwarteten unskalierten Standardunsicherheiten. Einzelheiten im
[Reparaturbericht](tools/open-computer-use-repair/README.md) und den Livebeobachtungen.

Neue Originalbelege bestätigen die Exponentialfunktion mit Offset und erstmals O8 mit fester sowie freier Glasdicke.
Die Wellenlängenanzeige beträgt 5,2E−7; die Dickenanzeige wird passend zur Eingabe in Metern interpretiert.
Die ersten Tangensreihen scheiterten an der Startwertsuche; fallende Reihen mit und ohne Offset passten anschließend.
Auch verrauschtes exponentielles Abklingen mit negativen beobachteten Y wurde erfolgreich angepasst. Die vollständige Options- und
Unsicherheitsabnahme bleibt offen; Zahlen und Grenzen stehen im [Referenzvergleich](native/REFERENZVERGLEICH.md).
Nach einer weiteren Absturzmeldung wurde nur die geprüfte Originalinstanz beendet und neu gestartet.
Die neue Instanz zeigte das Hauptfenster und ein reagierendes Datei-Menü; bestehende Belege blieben erhalten.

Ein weiterer Original-Splineblock erfasst drei Dämpfungsstellungen, alle acht Glättungen, kumulative
Glättung mit Interpolationsreset und Digitalisiergrenzen. Die natürliche kubische Interpolation und
die bisherige native Dämpfungsmischung erklären die gemessenen Werte nicht. Die genaue Originalformel
bleibt offen. Dateideskriptorprüfungen blieben über alle neuen Blöcke stabil. Einzelbelege stehen im Referenzvergleich.

Drei neue O1-Fokusfälle wurden im Original gesichert. Ein neuer FKS-Export gelingt und wird nativ
als Tabelle gelesen. Er bestätigt für diesen Ablauf die Speicherung der e-Eingaben mit sechs signifikanten
Stellen; damit lassen sich zuvor auffällige Reststreuungen erklären. Die vollständigen ursprünglichen
Eingaben und der Hauptdateibestand vor dem Export bleiben erhalten. Weitere O1-Abnahme und M6 bleiben offen.

## Richtungsänderung und Funktionsverbesserungen 0.6.0

Auf ausdrücklichen Nutzerauftrag ersetzt vollständiger, verlässlicher Funktionsumfang die bisherige
Suche nach exakter Originalparität. Alte Rundungsverluste und instabile Rechnungen werden nicht emuliert.
Die neue Funktionsabnahme priorisiert sechs tatsächliche Lücken. Implementiert sind skalenstabiler
orthogonaler Fit, C1-stetige Spline-Dämpfung, O1-Ableitungen mit vollständiger Eingabefortpflanzung,
M6-Korrekturrefits einschließlich μ-Unsicherheit, optionale Auftreffhöhenkorrektur und Grafik kopieren.
Quellstände und der vorige Sammelstatus wurden vor der Bereinigung archiviert. Gesamtprüflauf und
Paketnachweis werden unter `native/testprotokolle/funktionsverbesserung-2026-10-24/` geführt.

Build und abschließende Gesamtsuite von 0.6.0 bestehen. Ein unabhängiges Review erkannte eine doppelte
Skalierung der M6-Höhenunsicherheit; die Korrektur besitzt einen analytischen Regressionstest.
Der native Bedienlauf bestätigt O1, M6 und die Grafikzwischenablage. Zunächst fehlgeschlagene
Tastenkürzel wurden auf große Buchstaben im Linux-Testtreiber eingegrenzt; die korrekten Aufrufe
bestehen ohne Produktänderung. Der isolierte Debian-Paketlebenszyklus besteht einschließlich
Entfernung, Neuinstallation und bytegleich erhaltener Nutzerdokumente. Version 0.5.0 wird mit
unverändertem SHA-256 ins Paketarchiv verschoben; im Ausgabeverzeichnis bleibt die aktuelle Ausgabe.
Android, vollständiger FKS-Rückaustausch und die Projektlizenz bleiben ausdrücklich unbelegt bzw. offen.

## Ergänzende Fachprüfung und Korrekturen 0.6.1

Der Abgleich mit den Praktikumsanleitungen fand zwei Fehler in nichtlinearen Randfällen:
unterbestimmte Parameter konnten als erfolgreicher Fit mit null Unsicherheit erscheinen;
Exponential-Startwerte teilten bei wiederholten Anfangs-/End-X-Werten durch null.
Eine analytische, spaltennormierte Jacobian-Rangprüfung und Startwerte anhand der X-Grenzen beheben diese Fälle.
Unabhängige Ableitungsvergleiche und Regressionen prüfen die Änderungen.
Zusätzlich fehlten neue O1-/M6-Optionen in den Grafik-/Exportebenen und deren PDF-Optionsmap.
Die vollständige Weitergabe erhält tatsächliche Eingabeunsicherheiten, Fokusmodus und Fallhöhe;
das PDF zeigt nun auch das direkte Radienverhältnis neben dem korrigierten M6-Verhältnis.
Version 0.6.0 bleibt als unveränderter vorheriger Paketstand erhalten.
Fachquellen und Nachweisgrenzen: `native/testprotokolle/fachumfang-audit-2026-10-24.md`.

Die Gesamtsuite von 0.6.1 besteht mit 23879 wissenschaftlichen Assertions, 342 Backend- und
116 unabhängigen PDF-Prüfungen. Der isolierte Debian-Paketlebenszyklus besteht ebenfalls.
Der echte Recoverytest beendet ausschließlich die über XDG-Pfad, Programmdatei und pidfd
verifizierte eigene Testinstanz; der ungespeicherte Wert 543,21 und die O1-Optionen werden
beim Neustart wiederhergestellt. Der native Druckdialog erzeugt eine unabhängig geprüfte
einseitige PDF mit tatsächlichen Eingabeunsicherheiten. Ein vorheriger Druckversuch ohne
Dateibeleg bleibt als nicht bestätigt erhalten. Die Desktop-pidfd-Zahlen sind weiterhin unverändert.

## 26.10.2026 – 0.7.1: Datensätze in zusätzlichen Fenstern

- Mehrfachauswahl im Menü Fenster öffnet einen oder mehrere Datensätze gemeinsam in einem neuen Fenster.
- Unabhängige Kopien enthalten alle Messreihen und ungespeicherten Werte; Originale bleiben geöffnet.
- Eigene Bearbeitung, Berechnung und Speicherung pro Fenster; Wiederherstellung über alle offenen Fenster.
