# Fehlerhilfe und Wiederherstellung

Für Debian 13 / amd64, PhysPract Native 0.8.0.

| Symptom / Meldung | Vorgehen |
|---|---|
| App startet nicht / QML-Modul fehlt | Über APT installieren, damit Abhängigkeiten aufgelöst werden. Debian 12 ist nicht unterstützt. Start im Terminal mit `physpract-native` protokollieren. |
| Unvollständige oder ungültige Zeile | Jede belegte Zeile benötigt X und Y. Kopfzeilen entfernen; Dezimalkomma, Punkt oder Exponent verwenden. |
| Zu wenige aktive Punkte | Ausgeblendete Punkte prüfen; mehr Punkte als freie Parameter verwenden. M6 benötigt mindestens vier je Tabelle. |
| X-Werte besitzen keine Streuung | Verschiedene X-Werte eingeben. Senkrechte Geraden sind nicht als y=a·x+b darstellbar. |
| Startwerte außerhalb des Definitionsbereichs | Bei Logarithmus x>b, bei Hyperbel x≠b und bei Tangens Polstellen prüfen. |
| Nichtlineare Parameter sind durch die Messwerte nicht eindeutig bestimmbar | Unterschiedliche X-Werte, ausreichenden Messbereich und passendes Modell verwenden. Nullamplitude und gleichwirkende Parameter erlauben keine verlässliche Parameterbestimmung; mehr Wiederholungen derselben X-Werte lösen das nicht. |
| Keine Konvergenz: Startwerte oder Daten prüfen | Modell, Einheiten, Offset und Startparameter prüfen. Startwerte mit Semikolon trennen. |
| Keine ±-Werte nach Fehlerrechnung | Ergebnisnotiz prüfen. Ein erfolgreicher Fit garantiert keine konvergente Fehlerrechnung. |
| Doppelte X-Werte sind für Splines unzulässig | Doppelte X-Werte entfernen oder fachlich zusammenfassen. |
| X liegt außerhalb der interpolierten Kurve | Digitalisierung innerhalb des vorhandenen Stützbereichs durchführen. |
| M6-Kreisfit scheitert | Beide Tabellen prüfen; kollineare Punkte oder sehr kurze Kreisbögen vermeiden. Einheiten und Kugelzuordnung kontrollieren. |
| M6-Fallhöhe muss größer als beide Kugelradien sein | Gemessene Schwerpunktshöhe bis zum Papier in mm eingeben. Ohne gemessene Höhe die optionale Auftreffhöhenkorrektur ausschalten. |
| O1-Eingabeunsicherheiten fehlen | In Berechnungseinstellungen u(s), u(e) oder bei festem Fokus u(aF) in mm angeben. Null bedeutet nicht angegeben. Der Fit bleibt auch ohne ±-Werte erhalten. |
| Unsicherheitsrefit fehlgeschlagen | Eingaben und Unsicherheitsgrößen prüfen. Der erfolgreiche Hauptfit bleibt erhalten; es werden keine unvollständigen ±-Werte ausgegeben. |
| Ergebnis als veraltet markiert | Nach Eingabe-/Optionsänderungen erneut berechnen. |
| Formel ungültig / Division by zero / Function domain error or non-finite result | Syntax, Definitionsbereich und Rohwerte prüfen. Funktionsargumente mit Semikolon trennen. Fehlgeschlagene Umrechnung verändert keine Daten. |
| Automatische Umrechnung benötigt .ppn oder .ppproj | Ein natives Dokument oder das gesamte Projekt speichern; FKS erhält die Formeleinstellungen nicht. |
| LaTeX meldet unbekanntes resizebox | `\usepackage{graphicx}` in die Präambel des Zieldokuments aufnehmen. |
| Speichern fehlgeschlagen | Schreibrechte, freien Speicher und Zielverzeichnis prüfen; unter neuem Namen speichern. Bei FKS-Kompatibilitätsfehlern PPN wählen. |
| FKS-Export ohne Original oder Vergleichsbasis verweigert | PPN speichern. Für quelltreuen FKS-Rückexport das Original neu importieren; Endung ändern reicht nicht. |
| FKS-Export wegen nicht zugeordneter Option verweigert | Das vollständige native Dokument als PPN sichern. Die Fehlermeldung benennt die nicht sicher abbildbare Änderung. |
| O8 mit nichtstandardmäßiger fester Dicke nicht als FKS speicherbar | PPN wählen. Das Original fragt die feste Dicke bei jeder Berechnung erneut ab; FKS speichert keine verlässliche Vorgabe für den nächsten Fit. |
| Original-Spline-Dämpfung unterscheidet sich von der nativen | Original-Reglerwert wird getrennt bewahrt; native Dämpfung und Glättung sind eigene Verfahren. Siehe [Dateiaustausch](DATEIAUSTAUSCH.md). |
| Dokument überschreitet 16 MiB | Dokument auf mehrere Dateien aufteilen; eingebettete Originalarchive können viel Platz benötigen. Original vorher separat sichern. |
| Unbekanntes oder beschädigtes Dokument | Originaldatei erhalten. Unterstützte Formatversion und Sicherung prüfen; keine automatische Reparatur behaupten. |

## Abbruch

Strg+Ende bricht eine Hintergrundrechnung ab. Danach Daten/Optionen prüfen und neu berechnen.
Eingabeänderungen während einer Rechnung entwerten deren Ergebnisse.

## Wiederherstellung nach unerwartetem Ende

Beim nächsten Start bietet die App eine gefundene Sitzung zur Wiederherstellung an.
Bestätigen, Dokumente prüfen und unter eigenen `.ppn`-Namen speichern. Danach neu berechnen.

Unter Debian liegt die Sitzung normalerweise hier:

```text
~/.local/share/PhysPractNative/PhysPract Native/recovery.ppsession
```

Bei gesetztem `XDG_DATA_HOME` ersetzt dessen Wert `~/.local/share`.
Die App verwendet `QStandardPaths::AppDataLocation`; der tatsächliche Pfad hängt daher von der Umgebung ab.
Vor manuellen Eingriffen die App regulär schließen und eine Kopie der Sitzungsdatei sichern.
Reguläres bestätigtes Beenden entfernt die Wiederherstellung. Sie ersetzt kein Backup.
Nach Ablehnung einer Wiederherstellung kann eine spätere Änderung die Sitzungsdatei überschreiben.

## Fehlerbericht

Version, Debian-/Qt-Version, Modul, Modell, Optionen, Schritte und genaue Meldung festhalten.
Bei numerischen Fehlern ein minimales PPN-Beispiel mit Sollwert und Toleranz beilegen.
Private Namen und Originalpfade vor Weitergabe prüfen. Lokale Prüfprotokolle liegen unter `native/testprotokolle/`.
Desktopstörungen sind getrennt dokumentiert: [Werkzeugdiagnose](../tools/open-computer-use-repair/README.md).
