# PPN-Dateiformat, Version 2

Stand: native Implementierung 0.8.0. UTF-8-JSON, Endung `.ppn`, maximal 16 MiB einschließlich
gegebenenfalls eingebetteter Originalbytes. Lesen akzeptiert Version 1 und 2; Schreiben setzt Version 2.
Die Validierung in `src/backend.cpp`, insbesondere `validateDocument`, ist die maßgebliche Implementierung.
Ein formal lesbares Dokument garantiert noch keine fachlich berechenbaren Daten.

## Dokumentstruktur

| Feld | Typ | Bedeutung |
|---|---|---|
| format | String, erforderlich | Exakt `PhysPract Native` |
| version | Ganzzahl, erforderlich | 1 oder 2 beim Lesen, 2 beim Schreiben |
| module | String, erforderlich | `linear`, `nonlinear`, `spline`, `m6`, `o1` |
| metadata | Objekt, erforderlich | Dokumentvorgaben und Metadaten |
| options | Objekt, erforderlich | Dokumentweite Optionsvorgaben |
| series | Array, erforderlich | 1 bis 100 Messreihen |
| activeSeries | Ganzzahl, erforderlich | Nullbasierter Index innerhalb von series |
| originalFksBase64 | String, optional | Originalarchivbytes des letzten FKS-Imports/-Speicherns als Base64 |
| originalFksSource | String, optional | Herkunftspfad des importierten Originals |
| fksBaseline | Objekt, optional | Interpretierte Vergleichsbasis des Originalarchivs für sicheren FKS-Rückexport |

Originalbytes und `fksBaseline` ermöglichen den quelltreuen FKS-Rückexport. Nach erfolgreichem
FKS-Speichern werden beide auf den geschriebenen Stand aktualisiert; gewöhnliches PPN-Speichern
erhält sie. Ohne diese Herkunftsdaten ist kein FKS-Export möglich. Die PPN-Datei selbst bleibt JSON.
Unbekannte Felder werden beim normalen Lesen/Speichern im JSON-Objekt erhalten;
ein Modultransfer in ein neues Dokument ist keine Garantie für vollständige unbekannte Feldübernahme.

## Messreihe

`rows` und `rows2` sind erforderliche Arrays mit jeweils höchstens 10000 Zeilen.
`rows2` ist die zweite M6-Tabelle und darf sonst leer sein.
Optionale Felder: `name` (String, höchstens 200 Zeichen), `visible` (Boolean),
`options` und `metadata` (Objekte), `smoothingHistory` (nur Spline) sowie `originalFksOptions` (Objekt).
Bei importierten Splines enthält `originalFksOptions.splineDampingPosition` den ursprünglichen
Reglerwert −2 bis 2. Er ist unabhängig von der nativen Option `damping`; keine Gleichsetzung.

Jede Zeile ist ein Objekt mit den erforderlichen Strings `x`, `y`, `sigma`.
Leere Strings speichern leere Zellen; Zahlen bleiben als Text erhalten, einschließlich Dezimalkomma und Exponent.
Nichtleere Werte müssen endliche lesbare Zahlen sein; sigma darf nicht negativ sein.
`active` und `errorBar` sind optionale Booleans, Standard true bzw. false.
Beim Berechnen werden vollständig leere X/Y-Paare übersprungen; einseitig leere Paare sind ein Eingabefehler.

`smoothingHistory` enthält höchstens 256 Objekte mit `window` aus 5/7/9/11 und `degree` aus 1/2.
Die Reihenfolge ist verbindlich. Nach Öffnen rekonstruiert Berechnen die Verarbeitung.
Ab Version 0.6.0 verwendet eine Dämpfung größer null eine C1-stetige Hermite-/PCHIP-Methode.
Beim Neuberechnen älterer Dokumente können sich deshalb gedämpfte Kurven ändern; Rohwerte und Optionen bleiben erhalten.

## Metadaten und Vererbung

Dokumentfelder: `title`, `author1`, `author2`, `experiment`, `identifier`, `commonTitle`.
Reihenfelder: `parameters`, `xLabel`, `yLabel`, `xUnit`, `yUnit`.
Reihenmetadaten überschreiben zugehörige Dokumentvorgaben. Einheiten sind Strings mit höchstens
40 Zeichen ohne Zeilenumbruch. Die übrigen genannten Metadaten werden als Text verwendet.

## Rechen- und Darstellungsoptionen

Reihenoptionen überschreiben dokumentweite Optionen. Fehlende Werte folgen den Programmvorgaben.
Die Tabelle nennt die Vorgaben eines neuen Dokuments bzw. des Rechenkerns bei fehlenden Optionen.

| Feld | Typ / Standard | Verwendung |
|---|---|---|
| model | String / ordinary | Linear: ordinary/origin/orthogonal; nichtlinear: parabola/exponential/hyperbola/logarithm/tangent/o8 |
| sigma | Zahl / 1 | Manuelle Standardunsicherheit |
| focus | Zahl / 200 | O1-Fokusabstand in mm |
| sigmaS, sigmaE, sigmaFocus | Zahlen / 0 | O1-Standardunsicherheiten in mm; 0 bedeutet nicht angegeben; sigmaFocus nur bei festem Fokus |
| lambda | Zahl / 0.0006328 | O8-Wellenlänge in mm |
| thickness | Zahl / 1 | O8-Dicke in mm |
| samples | Ganzzahl / 150 | Spline-Ausgabestützpunkte |
| damping | Zahl / 0 | Spline-Dämpfung |
| window, degree | Ganzzahlen / 5, 1 | Glättung |
| mass1, mass2 | Zahlen / 20, 10 | M6-Massen in gemeinsamer Einheit |
| diameter1, diameter2 | Zahlen / 12.5992105, 10 | M6-Durchmesser in mm |
| correctHeight | Boolean / false | Optionale M6-Auftreffhöhenkorrektur |
| fallHeight | Zahl / 0 | Gemessene M6-Fallhöhe in mm; bei aktiver Korrektur größer als beide Kugelradien |
| start | String / leer | Startparameter, durch Semikolon getrennt |
| uncertainties, offset, vertex, manualSigma, adjustFocus, fitThickness, degrees | Boolean / false | Optionale Rechenmodi |
| fitZero, correctRadii | Boolean / true | O8-Nullpunktfit, M6-Radienkorrektur |
| logOffset | Boolean / true | Logarithmus mit additiver Konstante; false: zwei Parameter a, b ohne Konstante |
| grid | Boolean / true außer M6 | Diagrammgitter |
| residuals, common | Boolean / false bei fehlendem Feld | Residuenansicht und gemeinsame Kurven |

Nichtlineare Dokumente mit `model=ordinary` oder leerem Modell werden als Parabel berechnet.
Die Optionsobjekte werden nicht vollständig durch ein strenges JSON-Schema validiert;
fachliche Grenzen prüft zusätzlich der Rechenkern. Weitere reine Oberflächenoptionen können vorkommen.
`module` wird für die Berechnung aus dem Dokument übernommen, nicht als unabhängige Reihenoption gewählt.

## Migration und Schreibschutz

Version 1 verwendet dokumentweite Vorgaben. Beim Schreiben wird die Versionskennung auf 2 gesetzt;
bestehende Reihenüberschreibungen bleiben wirksam. Ergebnisse und Grafikcaches werden nicht als aktuelle Rechnung gespeichert.

Der PPN-Schreiber prüft bestehende `.ppn`-Ziele auf die Signatur `FBFK` und verweigert
auch das Überschreiben umbenannter Originalarchive. `.fks` verwendet einen getrennten quelltreuen
Codec mit Herkunfts- und Änderungsprüfung; siehe [DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md).
Beide Schreibwege verwenden `QSaveFile` zum atomischen Ersetzen.
Ungültige oder zu große Dokumente werden abgewiesen, bevor das bestehende Dokument ersetzt wird.
Eine Wiederherstellungssitzung `.ppsession` ist ein JSON-Array ungesicherter Dokumente und kein einzelnes PPN-Dokument.

## Beispiel

Die vollständige Datei [beispiele/gerade.ppn](beispiele/gerade.ppn) enthält fünf Punkte auf `y=2x+1`.
Öffnen und Berechnen soll Steigung 2 und Abschnitt 1 ergeben.

## Formelumrechnung ab 0.8.0

Messreihen können `conversion` (erste Tabelle) und `conversion2` (zweite Tabelle)
enthalten. Jedes Objekt enthält `enabled` (Boolean), `x` und `y` (Formelstrings).
Die Syntax wird beim Öffnen validiert. Formeln verwenden die ursprünglichen Werte derselben
Zeile; sie werden gleichzeitig angewendet. Zeilen können `inputX` und `inputY` als
Zahlstrings oder leere Strings enthalten. `x` und `y` enthalten die berechneten Werte.
Bei aktiver Umrechnung verwenden spätere Formelanpassungen diese Rohwerte; Abschalten
entfernt die Rohwertfelder und behält die berechneten Koordinaten. Zellrechnungen mit `=`
werden beim Bestätigen ausgewertet und nicht als dauerhafte Zellformel gespeichert.

## Projektformat `.ppproj`, Version 1

UTF-8-JSON mit `format: "PhysPract Project"`, `version: 1`, `documents` (1 bis 1000
vollständige PPN-Dokumentobjekte), `current` (nullbasierter aktiver Dokumentindex) und
`displayed` (Array von Objekten mit `document`- und `series`-Index für die Tabellenauswahl).
Maximal 128 MiB für das Projekt und 16 MiB pro eingebettetem Dokument. Schreiben verwendet
`QSaveFile`. Öffnen validiert sämtliche Dokumente und Indizes vor der Übernahme und fügt
die Datensätze zu den offenen hinzu. Einzeldateipfade, Undo-Verlauf und Ergebnis-Caches
werden nicht im Projekt gespeichert. Nach Öffnen müssen Ergebnisse neu berechnet werden.
