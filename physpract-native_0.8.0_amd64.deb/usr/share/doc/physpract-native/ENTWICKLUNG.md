# Entwicklerübersicht

Stand 0.8.0. Buildbefehle und Systemabhängigkeiten stehen in [README.md](README.md).

## Zuständigkeiten

| Pfad | Verantwortung |
|---|---|
| src/core.h, src/core.cpp | Qt-unabhängiger Rechenkern, Modelle, Spline, M6 und O1 |
| src/backend.h, src/backend.cpp | Dokumente, Optionen, Undo/Redo, PPN/Projekte, Formelumrechnung, Tabellenimport, Hintergrundjobs und Revisionen |
| src/formula.h | Begrenzter arithmetischer Parser, Syntaxprüfung und sichere Formelberechnung |
| src/cellrange.* | Zellbereichs- und Zwischenablageoperationen |
| src/fks.*, src/fks_*.h | Quelltreuer FKS-Codec, Archiv-/Zustands-/Gitterparser, Änderungsprüfung und Cacheentwertung |
| src/plot.* | Diagrammdarstellung und Rendering |
| src/analysisexport.* | PDF-/Druckbericht und LaTeX-Tabellen |
| src/main.cpp | Qt-Start, CLI-Prüfmodi, QML-Anbindung |
| qml/Main.qml, DataTable.qml, CellEditor.qml | Fenster, Menüs, Tabellen und Zellbearbeitung |
| scripts/ | Lokaler Build, Start, Tests und Debian-Paket |
| packaging/, CMakeLists.txt | Desktop-/MIME-Integration und alternativer CMake-/CPack-Build |

QML bedient das Backend; dieses hält Dokumentzustand und startet Berechnungen über QtConcurrent.
Der Rechenkern erhält Punkte und Optionen. Abbruchflag und Revisionsprüfung verhindern die Übernahme veralteter Ergebnisse.
Plot und Export verwenden den berechneten Zustand. Nach erneutem Öffnen werden Ergebnisse neu berechnet.

## Prüfungen

```bash
native/scripts/build-local.sh
native/scripts/test.sh
```

Das Testskript isoliert Nutzerdaten in einem temporären Verzeichnis, verwendet Offscreen-QML und prüft:
C++-Rechenkern, analytische O1- und M6-Höhenreferenzen, Zellbereiche, FKS, unabhängige numerische Referenzen, Backendintegration,
PDF-/LaTeX-Ausgabe, Formelparser, automatische Umrechnung, Projekt-Roundtrips, fünf Moduloberflächen, Umrechnungsdialog und unveränderte Originalarchive.
Python-Referenzen benötigen zusätzliche Testabhängigkeiten; siehe [DEPENDENCIES.txt](DEPENDENCIES.txt).
FKS-Prüfungen umfassen Archivstruktur, Gitter, Zustandsbäume, gezielte Änderungen und
Dokumentrückexport. `native/build/fks-roundtrip import INPUT.fks OUTPUT.ppn` und
`native/build/fks-roundtrip export INPUT.ppn OUTPUT.fks` verwenden denselben Codec,
begrenzen Dateien auf 16 MiB und verweigern identische Ein-/Ausgabepfade.
Ein erfolgreicher automatischer Lauf ersetzt keinen nativen Bedienlauf oder Android-Nachweis.
Originalvergleiche dienen konkreten Funktionsfragen; historische Fehlerparität ist kein Freigabekriterium.

`tests/clean_debian_acceptance.sh` ist nur für die markierte isolierte Debian-Testumgebung vorgesehen.
Nicht als allgemeines Hostinstallationsskript verwenden. Rohprotokolle bleiben unter `testprotokolle/` erhalten.

## Paketprüfung und Freigabe

1. Versionsangaben und aktuellen Status vergleichen; Anwendung und Dokumentation müssen denselben Stand nennen.
2. Direkten Build und vollständiges Testskript ausführen; Logs mit Umgebung und Ergebnis sichern.
3. Mit `scripts/package.sh` paketieren. Das Skript erwartet `native/build/physpract-native`.
4. Paketinhalt und SHA-256 prüfen. Saubere Installation, Start, Entfernung und Neuinstallation isoliert nachweisen.
5. Umfang und Grenzen anhand der [Funktionsabnahme](FUNKTIONSABNAHME.md) bewerten; keine Freigabe aus Testzahlen allein ableiten.

Der CMake-/CPack-Weg ist alternativ vorbereitet, bislang aber nicht als ausgeführter Paketweg abgenommen.
Dokumentationsänderungen können ohne Änderung der Produktbinärdatei paketiert werden;
solche Pakete brauchen einen eigenen nachvollziehbaren Buildnachweis.
Bestehende veröffentlichte oder archivierte Paketdateien nicht stillschweigend ersetzen.

## Aufbewahrung und Lizenz

`dist/` enthält das aktuelle gebaute Paket. Ältere Pakete und historische Sammeldokumente liegen unter
[archiv/](../archiv/README.md). Manifest und Verlauf erlauben Rückverfolgung.
Originaldaten und Testfixtures bleiben an ihren bisherigen Pfaden, da Tests darauf zugreifen.
Build-/Wine-Verzeichnisse bleiben lokal; sie sind keine Produktbestandteile.
Die Projektlizenz ist noch nicht festgelegt. Ohne Rechteklärung keine öffentliche Freigabe erklären;
[Drittkomponenten](THIRD_PARTY.md) dokumentiert die vorhandenen Abhängigkeiten.

Die installierte Dokumentation enthält die Handbücher und PPN-Beispiele.
Links auf Quellcode, Tests, Archiv oder Projektstamm setzen den vollständigen Quellbaum voraus.
Der historische Paketnachweis von 0.6.1 steht unter `testprotokolle/0.6.1/clean-debian/`.
