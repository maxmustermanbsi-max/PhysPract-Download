# PhysPract Native für Debian

Native C++17-/Qt-6-/QML-Anwendung für Debian 13 (trixie), amd64. Quellstand 0.8.0 umfasst alle fünf vorgesehenen Auswertungsmodule und die Verbesserungen der [Funktionsabnahme](FUNKTIONSABNAHME.md). Maßstab sind vollständige und mathematisch verlässliche native Auswertungen. Fehler und Rundungsverluste des Windows-Originals werden nicht nachgebildet. 0.7.0 ergänzt den quelltreuen FKS-Austausch für bestehende Originaldokumente; Umfang und Grenzen stehen in [DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md). Den aktuellen Nachweisstatus enthält [STATUS.md](STATUS.md). Android folgt nach der Debian-Funktionsabnahme und ist noch nicht gebaut.

## Neu in 0.8.0

LaTeX-Tabellen kopieren oder exportieren, Tabellen im PDF/Druck nebeneinander skalieren,
x/y-Export ohne Hilfsspalten, Zellrechnungen mit `=`, einmalige oder automatische
Umrechnung mit gespeicherten Rohwerten sowie vollständige `.ppproj`-Projekte.
Alle Funktionen der bisherigen Versionen einschließlich zusätzlicher Fenster sind enthalten.
Bedienung und Formatgrenzen stehen im nativen Handbuch und im PPN-Formatdokument.

## Installieren und starten

Das Paket wird unter `dist/physpract-native_0.8.0_amd64.deb` im Projektstamm gebaut:

```bash
sudo apt install ./dist/physpract-native_0.8.0_amd64.deb
physpract-native
```

Der Programmeintrag heißt **PhysPract Native**. Das Debian-Paket enthält weder Wine noch Windows-Dateien. `.ppn`- und `.fks`-Dateien werden der App zugeordnet. Debian 12 ist wegen Qt 6.8 keine unterstützte Zielversion.

Ohne Installation aus diesem vorbereiteten Arbeitsverzeichnis starten:

```bash
./PhysPract-Native-starten.sh
```

Zum Entfernen: `sudo apt remove physpract-native`. Eigene Dokumente und gegebenenfalls Wiederherstellungsdaten werden nicht automatisch gelöscht.

## Bedienung

Die Fensteraufteilung entspricht jetzt den Abbildungen der Originalhilfe: Gitter links, Rechenoptionen darunter, Grafik rechts und bei Regression/O1 ein Ergebnisbereich darunter. Einzelheiten und Vergleichsgrundlagen stehen in LAYOUT.md.

- Datei → Auswertung wechselt die Auswertungsart (linear, nichtlinear, Spline, M6 oder O1) unter Beibehaltung der Messwerte. Datei → Neuer Datensatz legt ein leeres Dokument an. Unter Fenster wählt man eine oder mehrere Messreihen aus; ihre Tabellen stehen nebeneinander, ihre Kurven erscheinen im selben Diagramm.
- Aktionen → Analytisches Beispiel lädt Testdaten. Strg+F9 bzw. Aktionen → Berechnen/Interpolieren startet die Hintergrundberechnung; Strg+Ende bricht ab. Nach Eingabeänderungen werden alte Ergebnisse als veraltet markiert.
- Tabellen erlauben Dezimalkomma, Punkt und wissenschaftliche Schreibweise. Auch die sichtbaren Leerzeilen können direkt bearbeitet werden. Fehlende Zahlen werden nicht zu null.
- Zellbereiche mit der Maus ziehen oder mit Umschalt+Pfeiltasten erweitern. Strg+C/X/V kopiert, schneidet aus und fügt ab der Zielzelle ein; Entf leert die Auswahl. Ein einzelner Zwischenablagewert füllt die Auswahl, passende kleinere Rechtecke werden wiederholt. Fehlerhafte Zahlen oder unpassende Größen ändern keine Daten. TAB wechselt die Zelle; F2, Doppelklick oder Zahleneingabe beginnt die Bearbeitung, Escape verwirft sie. Leere Zellen und die ursprüngliche Zahlengenauigkeit bleiben erhalten. Innerhalb der App werden bei X/Y-Bereichen auch Aktiv-/Fehlerbalkenflags übertragen.
- Das Gitter-Kontextmenü bietet Kopieren/Einfügen der ganzen Tabelle, Ausblenden einzelner Messwerte, Fehlerbalken, eine optionale σY-Spalte und Zeilenverwaltung. σY und Fehlerbalken gewichten den Fit nicht. Datenformat der Zwischenablage: X, Y, optional σY, aktiv (0/1), Fehlerbalken (0/1); TAB, Semikolon oder Leerzeichen trennen Spalten. Kopfzeilen vor dem Import entfernen. M6 besitzt ein Kontextmenü je Tabelle.
- Rückgängig/Wiederholen: Strg+Z/Strg+Umschalt+Z. M6-Korrekturen stehen unter Bearbeiten → Korrekturen. Tausch, X-Umkehr und Faktor 10 lassen sich rückgängig machen; Kugeldurchmesser/Massen werden dabei nicht skaliert.
- Datei → Messung hinzufügen/entfernen/vorherige/nächste verwaltet mehrere Messreihen. Über Messung benennen/auswählen lassen sich Name und Sichtbarkeit für gemeinsame Grafiken ändern. Rechenoptionen, Messparameter und Achsentexte gelten jetzt pro Messreihe. Dokumenttitel, Namen der Bearbeitenden, Kennung und Versuchsbezeichnung gelten für den Datensatz.
- Aktionen → Kurven gemeinsam zeichnen zeigt berechnete, sichtbar geschaltete Reihen und offene Dokumente desselben Moduls. Die aktive Reihe kann ebenfalls ausgeschlossen werden. Restabweichungen und gemeinsame Fitgrafiken sind getrennte Ansichten.
- Doppelklick auf Titel, Autor oder Achsenbeschriftung öffnet das passende Eingabefeld. Auch unter Bearbeiten → Titel, Autor und Einheiten lassen sich die Grafikangaben ergänzen. Autoren erscheinen auch in PNG/PDF und beim Druck. X-/Y-Einheiten gelten je Messreihe und dienen der Beschriftung; M6 verwendet mm, die transformierte O1-Grafik mm². Achsengrenzen und Zoom passen sich automatisch an.
- Modellabhängige Zusatzoptionen und Startwerte stehen unter Aktionen → Berechnungseinstellungen.
- O1 berechnet bei festem und angepasstem Fokus Brennweite und Hauptebenenabstand im physikalischen Steigung-1-Modell. Die drei Rohunsicherheiten für s, e und den gemeinsamen Fokusabstand werden durch vollständige Wiederanpassungen fortgepflanzt. Die genauen Annahmen stehen in [MATHEMATIK.md](MATHEMATIK.md).
- M6 bietet neben der Stoßpunktkorrektur eine optionale Auftreffhöhenkorrektur. Geben Sie die Fallhöhe und beide Kugeldurchmesser in mm ein. Die Fehlerrechnung wiederholt die vollständige aktivierte Korrektur- und Fitkette und umfasst auch das korrigierte Massenverhältnis.
- Splines: Die Dämpfung erhält stetige Anstiege; D=1 verwendet formtreue PCHIP-Steigungen. Erst interpolieren, dann Verfahren auswählen und mit Strg+Umschalt+F9 glätten. Wiederholung wirkt auf die letzte Kurve. Die Glättung läuft abbrechbar im Hintergrund; erfolgreiche Schritte werden gespeichert. Nach dem Wiederöffnen stellt die erste Berechnung die gespeicherte Verarbeitung wieder her. Aktionen → Neu interpolieren setzt sie ausdrücklich zurück. Rückgängig/Wiederholen erhält die jeweilige Verarbeitungshistorie.
- Digitalisierung: Fadenkreuz aktivieren und Grafik anklicken, dann X im Dialog ändern oder bestätigen. Abbrechen verwirft die Wahl. Der Y-Wert steht danach in der Statuszeile.
- F11 vergrößert die Grafik. Ein Messpunktklick markiert die passende Tabellenzeile, auch bei Leerzeilen oder der zweiten M6-Tabelle. Bei M6 wechselt Aktionen → Editor/Ergebnisse zwischen Eingabegittern und Kreisresultaten links.
- Import/Export → Grafik kopieren oder Strg+G kopiert die beschriftete Grafik als Bild in die Zwischenablage. Import/Export → Auswertung als PDF gibt Messwerte, Grafik, Regression und Fehler aus. Dieselben Inhalte werden über Datei → Auswertung drucken bzw. Strg+P gedruckt. Zusätzliche Berichtskapitel und Recheneinstellungen werden nicht ausgegeben. Lange Tabellen laufen auf Folgeseiten mit wiederholtem Tabellenkopf weiter. Grafik als PNG exportiert die Grafik.

## Tabellenformeln, LaTeX und Projekte

- **Import / Export → Tabellen als LaTeX kopieren / exportieren** gibt die unter **Fenster** ausgewählten Tabellen als einfügbaren LaTeX-Code aus. Das Zieldokument benötigt `\usepackage{graphicx}`. Mehrere Tabellen stehen als proportional skalierte Blöcke nebeneinander. Auch PDF und Druck ordnen ausgewählte Tabellen nebeneinander an. Texttabellen, LaTeX und Berichtstabellen enthalten nur die beiden Koordinatenspalten; interne Kopierfunktionen erhalten weiterhin Unsicherheiten und Messwertflags.
- Im **Kontextmenü einer Tabelle → Umrechnungsassistent / Formeln** lassen sich für x und y Formeln eingeben, etwa `x/1000` und `y*9,81`. Beide verwenden die ursprünglichen Werte derselben Zeile. Eine leere Formel entspricht `x` beziehungsweise `y`. Einmalige Umrechnung kann auf ausgewählte x/y-Zellen begrenzt werden. Die automatische Umrechnung gilt für die ganze Tabelle, einschließlich neuer Eingaben, Einfügen und Textimport. Formelanpassungen verwenden die gespeicherten Rohwerte; die Tabelle zeigt die berechneten Werte. Beim Bearbeiten erscheint der Rohwert. Abschalten erhält die berechneten Werte. M6 hat getrennte Einstellungen für beide Tabellen.
- Zellrechnungen beginnen mit `=`, zum Beispiel `=sqrt(2^2+3^2)` oder `=y/2`. Die Rechnung wird beim Bestätigen ausgeführt. `x` und `y` beziehen sich auf dieselbe Zeile, bei aktiver Umrechnung auf deren Rohwerte. Das Ergebnis wird dann als Eingabewert umgerechnet. Unterstützt werden `+ - * / ^`, Klammern, `pi`, `e`, `sqrt`, `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `abs`, `exp`, `ln`, `log`, `log10`, `pow`, `min` und `max`. Winkel in Radiant; mehrere Funktionsargumente mit Semikolon, etwa `pow(x;2)`. Dezimalkomma und wissenschaftliche Schreibweise sind möglich. Ungültige Rechnungen und Umrechnungen ändern keine Daten. Rückgängig stellt den gesamten vorherigen Zustand wieder her.
- **Datei → Gesamtes Projekt speichern** speichert alle im aktuellen Fenster geöffneten Datensätze mit sämtlichen Messreihen, Rohwerten, Formeln, Optionen, Metadaten und Tabellenauswahl in einer `.ppproj`-Datei. **Datensatz öffnen** öffnet auch Projekte und fügt deren Datensätze hinzu, sodass bereits offene Arbeit erhalten bleibt. Ergebnisse werden nach dem Öffnen neu berechnet. **Projekt speichern unter** legt eine weitere Projektdatei an. Einzelne Datensätze bleiben als `.ppn` speicherbar; aktive automatische Umrechnung kann nicht verlustfrei als FKS gespeichert werden.

## Dateien und Wiederherstellung

`.ppn` ist ein eigenes, versioniertes JSON-Dokument. Formatversion 2 speichert Optionen und Verarbeitungsschritte je Messreihe. Die App liest weiterhin Version 1 und übernimmt deren dokumentweite Vorgaben; beim nächsten Speichern wird auf Version 2 aktualisiert. Ältere App-Versionen können die neue Datei dadurch nicht versehentlich mit falschen Rechenoptionen auswerten. Es enthält alle eingegebenen Reihen, Aktiv-/Fehlerbalkenflags, Metadaten und Optionen. Speichern verwendet QSaveFile mit atomischem Ersetzen. Ergebnisse werden nach dem Öffnen neu berechnet. Gespeicherte Spline-Glättungsschritte werden dabei automatisch in derselben Reihenfolge wiederholt; alte Grafik-/Fitcaches werden nicht als aktuelle Rechnung übernommen.

FKS-Öffnen und -Speichern unterstützt bestehende Originaldokumente mit mehreren Messreihen, beiden M6-Tabellen und den zugeordneten Metadaten/Modelloptionen. Unveränderte Archive bleiben bytegenau; unbekannte Felder werden erhalten. Nicht sicher abbildbare Änderungen werden abgewiesen. Neue native Dokumente oder ältere PPN ohne importiertes Original und Vergleichsbasis können nicht als FKS gespeichert werden. PPN bleibt das vollständige native Format. Belegt ist PhysPract 3.4.7b04, keine beliebige unbekannte Version. Insbesondere Original-Spline-Dämpfung und feste O8-Dicke haben eigene Grenzen; vor dem Rückexport [DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md) beachten. Texttabellen können als TSV importiert/exportiert werden. Die alte Hauptdateiverwaltung ist nicht implementiert.

Ungesicherte Dokumente werden in `QStandardPaths::AppDataLocation/recovery.ppsession` wiederhergestellt angeboten. Reguläres Beenden fragt bei Änderungen nach Speichern und entfernt die Wiederherstellung nach bestätigtem Beenden. Wiederherstellung ist eine lokale Sicherheitskopie, keine Versionsverwaltung.

## Bauen

Standardweg auf Debian 13:

```bash
sudo apt install poppler-utils build-essential cmake ninja-build qt6-base-dev qt6-declarative-dev libeigen3-dev \
  qml6-module-qtquick qml6-module-qtquick-controls qml6-module-qtquick-layouts \
  qml6-module-qtquick-window qml6-module-qtquick-templates \
  qml6-module-qtqml-workerscript qml6-module-qtqml-models
cmake -S native -B native/build-cmake -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build native/build-cmake
ctest --test-dir native/build-cmake --output-on-failure
```

Getesteter Build in dieser Umgebung: GCC 14.2, Qt 6.8.2, Eigen 3.4.0. Mangels sudo-Zugang wurden Debian-Entwicklungspakete in `.build-deps/root` entpackt; `native/scripts/build-local.sh` baut mit diesen Dateien oder mit systemweit installierten Headern. Die Anwendung benutzt dynamische Qt-Systembibliotheken. Das ist kein in das Produkt eingebauter alternativer Qt-Stack.

```bash
native/scripts/prepare-local-deps.sh  # nur für den optionalen Rootless-Aufbau
native/scripts/build-local.sh
native/scripts/test.sh
native/scripts/package.sh
```

Der Paketbau erwartet den direkten Build unter `native/build`. Das CMake-Projekt bietet alternativ CPack (`cpack -G DEB` im CMake-Buildverzeichnis); der CMake-/CPack-Weg wurde hier noch nicht ausgeführt. Compiler-/QML-/Bibliotheksversionen stehen in `native/DEPENDENCIES.txt`. Der Quellcode ist plattformneutral vorbereitet; Android ist in diesem Debian-Auftrag weder gebaut noch geprüft.

## Änderungen in 0.7.1

Unter **Fenster → Datensätze in neuem Fenster öffnen …** können Sie einen oder mehrere
geöffnete Datensätze auswählen. Die Auswahl öffnet sich gemeinsam in einem zusätzlichen
Fenster mit eigener Bearbeitung, Berechnung und Speicherung. Alle Messreihen, Optionen,
Metadaten und ungespeicherten Werte werden kopiert. Originale bleiben geöffnet.
Die Kopien erhalten beim Speichern einen eigenen Dateipfad. Weitere Fenster können auch
aus einem zusätzlichen Fenster geöffnet werden. Beim Schließen werden dessen ungespeicherte
Änderungen abgefragt; die Wiederherstellung erfasst die Änderungen aller Fenster.

## Änderungen in 0.7.0

- Bestehende FKS öffnen, Tabellen und zugeordnete Metadaten/Optionen ändern und wieder als FKS speichern.
- Mehrere Originalmessreihen und beide M6-Tabellen erhalten; unveränderte Archive bytegenau zurückgeben.
- Unbekannte Originalfelder bewahren und unsichere Änderungen vor dem Schreiben abweisen.
- Logarithmische Regression wahlweise ohne additive Konstante berechnen.

Build und Testsuite sind in [TESTERGEBNISSE-0.7.0.txt](TESTERGEBNISSE-0.7.0.txt) dokumentiert.
Der getrennte Paketnachweis steht im [aktuellen Status](STATUS.md).

## Änderungen in 0.6.1

- Nichtidentifizierbare nichtlineare Parameter werden mit einer Fehlermeldung abgewiesen; keine scheinbar sicheren ±0.
- Exponential-Startwerte verwenden die tatsächlichen X-Grenzen und vertragen wiederholte Endpunkte.
- PDF-Ausgaben erhalten die tatsächlichen O1-Unsicherheiten und den Fokusmodus sowie aktive M6-Höhenkorrekturen.
- Das direkte M6-Radienverhältnis steht zusätzlich zum korrigierten Verhältnis im PDF.

Die vollständige neue Testsuite und der isolierte Debian-Paketlebenszyklus haben bestanden.
Der kontrollierte Absturztest stellt den ungespeicherten Messwert samt O1-Optionen wieder her.
Einzelheiten: [Testergebnisse 0.6.1](TESTERGEBNISSE-0.6.1.txt).

## Änderungen in 0.6.0

- Skalenstabile orthogonale Regression durch Zentrierung und gemeinsame Normierung.
- C1-stetige Spline-Dämpfung mit Übergang vom natürlichen Spline zu formtreuem PCHIP.
- Brennweite, Hauptebenenabstand und gemeinsame Fehlerfortpflanzung für beide O1-Fokusmodi.
- Sieben M6-Unsicherheitsausgaben einschließlich des korrigierten Massenverhältnisses; vollständige Korrekturketten statt festgehaltener korrigierter Punkte.
- Optionale M6-Auftreffhöhenkorrektur mit expliziter Fallhöhe.
- Beschriftete Grafik über Menü und Strg+G kopieren.

Gemeinsamer Build, Gesamttests, nativer Bedienlauf und isolierter Paketlebenszyklus sind protokolliert. Die [Testergebnisse](TESTERGEBNISSE-0.6.0.txt) und der [Status](STATUS.md) nennen den belegten Umfang und die Grenzen. Die [Funktionsabnahme](FUNKTIONSABNAHME.md) beschreibt die Kriterien.

Für den damaligen Stand 0.6.0 war FKS auf Tabellenimport begrenzt. Der aktuelle FKS-Umfang von 0.7.0 steht in [DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md); PPN bleibt das vollständige native Dokumentformat.

Die früheren Entwicklungsstände und Originalversuche bleiben im [archivierten Status vor 0.6.0](../archiv/2026-10-24/STATUS-vor-0.6.0.md) erhalten. [TESTERGEBNISSE-0.5.0.txt](TESTERGEBNISSE-0.5.0.txt) und [testprotokolle/0.5.0/clean-debian/](testprotokolle/0.5.0/clean-debian/) dokumentieren die damalige saubere Installation und Paketprüfung; sie sind keine Prüfung des neuen Pakets.

## Weiterführende Dokumentation

[Arbeitsbeispiele](BEISPIELE.md), [mathematische Referenz](MATHEMATIK.md),
[PPN-Format](PPN-FORMAT.md), [Fehlerhilfe](FEHLERHILFE.md) und [Entwicklerübersicht](ENTWICKLUNG.md).
Im Quellbaum ergänzen [Projektübersicht](../README.md) und [Verlauf](../VERLAUF.md) den Einstieg.

Die [Funktionsabnahme](FUNKTIONSABNAHME.md) und der [aktuelle Status](STATUS.md) sind die Einstiege für den neuen Stand. [Historische Originalvergleiche](REFERENZVERGLEICH.md) bleiben als Erkenntnisse erhalten; offene Forensik ist kein zusätzliches Freigabetor. Die Projektlizenz bleibt offen; Hinweise zu Drittkomponenten stehen in [THIRD_PARTY.md](THIRD_PARTY.md).
