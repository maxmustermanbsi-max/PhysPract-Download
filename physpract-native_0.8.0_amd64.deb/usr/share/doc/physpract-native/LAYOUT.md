# Oberfläche nach dem Original

Die Ausgabe 0.2.0 richtet die Anordnung der Auswertungsfenster nach den mitgelieferten Abbildungen der Originalhilfe aus. Grundlage sind die lokal aus `Anleitung/PhysPract.chm` gelesenen Dateien `images/LinregForm.gif` (752×566), `NonLinregForm.gif` (752×591), `SplinesForm.gif` (752×586), `O1Form.gif` (753×591) und `M6Form.gif` (758×553). Die Bilder werden als Referenz verwendet und nicht in die Anwendung eingebaut.

## Übernommene Anordnung

- Klassische Menüleiste mit Datei, Bearbeiten, Aktionen, Import/Export, Fenster und Hilfe. Eine kompakte Symbolleiste darunter bietet Neu, Öffnen, Sichern, Drucken, Rückgängig, Kopieren, Einfügen, Berechnen/Interpolieren, Abbrechen, Einstellungen, Vollbild und Hilfe. Kurzinfos benennen jede Funktion. Logo-Kachel und Kartenansicht der ersten nativen Fassung entfallen.
- Schmale Eingabespalte links (etwa 30 % der Fensterbreite), Grafik rechts. Die Teilung kann wie ein klassischer Fenstersplitter verschoben werden.
- Weißes Eingabegitter mit Zeilennummern `# 01`, `X-Wert`/`Y-Wert` bzw. `s (mm)`/`e (mm)`, feinen Zellrahmen und Bildlaufleiste. Leere Eingabezeilen bleiben sichtbar. Zusätzliche Status-/Fehlerfunktionen sind über das Gitter-Kontextmenü erreichbar und verbreitern die Standardtabelle nicht.
- Lineare und nichtlineare Regression: Messabweichung mit Standard-Schalter und Berechnungsart unter dem Gitter; Ergebnisstreifen unter der Grafik.
- Spline: Stützpunktzahl und Dämpfung nebeneinander unter dem Gitter, Glättungsauswahl darunter. Die Grafik nutzt den rechten Bereich mit einer schmalen Ergebniszeile für die Splinegleichung darunter.
- O1: Fokusabstand links unter der Tabelle, danach Messabweichung/Standard und feste orthogonale Berechnungsart; Ergebnisstreifen rechts unten.
- M6: Eingabemodus mit zwei Tabellen und Kugelparametern links, Grafik rechts. Nach der Rechnung ersetzen Kreisresultate die linke Eingabeansicht; Aktionen → Editor/Ergebnisse wechselt zurück. Die Grafik zeigt rote angepasste Kreise/reduzierte Punkte und grüne gemessene Punkte mit Kreuzmarkierung. In der Einzelansicht werden die Koordinaten wie in der Referenz um das erste Kreismittelpunktpaar verschoben und als X−Xm/Y−Ym bezeichnet; Eingabewerte bleiben unverändert.
- Graue Fensterflächen, weiße Diagrammfläche, feines gepunktetes Gitternetz, dünne blaue Regressions-/Splinekurven und rote offene Messpunktsymbole. Keine zusätzlichen großen Überschriften im Arbeitsbereich.
- Statuszeile unten mit Datum, Messungszähler, Bearbeiternamen und aktuellem Arbeitsstatus.

## Prüfung und Grenzen

`--ui-smoke ... --module ... --check-layout` prüft für jedes Modul die tatsächlichen QML-Geometrien: Breite/Position der Eingabespalte, dominierende Grafik rechts, einzeilige Gitterköpfe und Lage/Sichtbarkeit der Ergebnisbereiche. Bei sichtbarem Gitter werden außerdem die fünfte Tabellenzeile und eine echte Tastatureingabe mit Dezimalkomma samt Fokuswechsel geprüft. Zusätzlich werden rechteckige Auswahl per Maus und Shift-Pfeilen, gezieltes Einfügen, Leeren sowie Bearbeitungsabbruch mit Escape durch echte Fensterereignisse geprüft. Der Metadatendialog wird in jedem Modul geöffnet; Titel und Autor werden per Tastatur eingegeben. M6/O1 zeigen ihre festen Einheiten an. Die dabei erzeugten Bildschirmaufnahmen liegen unter `native/screenshots/`.

Die ursprüngliche Windows-Titelleiste wird durch die native Debian-Fensterdekoration ersetzt. Die Abbildungen der Hilfe zeigen unterschiedliche historische Originalversionen; ein aktueller Live-Vergleich bleibt gemäß Umsetzungsplan offen. Die Anordnung der fünf Fachfenster ist angepasst, eine pixelgenaue Zusage für alle Dialoge und das gesamte originale MDI-Fensterverhalten ist damit nicht verbunden. Noch nicht fachlich abgesicherte Originalfelder werden nicht allein zum optischen Füllen mit erfundener Funktion versehen. Die noch offenen Funktionen und Abnahmen stehen in STATUS.md.

## Anpassungen 0.4.1

Die Einzelansicht behält die schmale Eingabespalte. Mehrfachauswahl unter Fenster verbreitert sie für nebeneinander angeordnete Tabellen; weitere Reihen sind horizontal erreichbar. Jede Tabelle aktiviert beim Bearbeiten ihre eigene Messreihe. Grafiktitel, Autoren und beide Achsen öffnen per Doppelklick das jeweilige Eingabefeld. Achsentexte und Einheiten sind jetzt auch in M6/O1 bearbeitbar; die ursprünglichen physikalischen Einheiten bleiben die Vorgabe. Jede Achse besitzt sechs Hauptintervalle mit gerundeten Schrittweiten. Bei M6 bleibt das Achsenverhältnis gleich, damit Kreise als Kreise erscheinen.

## PDF und Bearbeiter

Der PDF-Export verwendet Seiten im Verhältnis 4:3 (320 × 240 mm): Messwerttabellen links, beschriftete Grafik rechts oben, Regression und Messabweichungen darunter. Lange Tabellen erhalten Folgeseiten mit wiederholten Spaltenköpfen; alle Messwerte, Unsicherheiten und Aktiv-Markierungen bleiben enthalten. Druckausgaben übernehmen dieselbe Spaltenanordnung innerhalb des gewählten Papierformats. Ein Klick auf den Bearbeiternamen in der Statuszeile öffnet den Metadatendialog und fokussiert das Autorenfeld. Unter Hilfe → Über stehen Autor Benjamin Simon und die Kontaktadresse benjamin-alexander.simon@tu-ilmenau.de.
