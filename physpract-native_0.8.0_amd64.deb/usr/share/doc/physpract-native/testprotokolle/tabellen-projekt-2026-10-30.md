# Tabellenformeln, Exporte und Projektspeicherung – Prüfung 2026-10-30

Implementiert und mit zwei Luna-Subagenten bearbeitet:

- LaTeX-Kopieren und `.tex`-Export der ausgewählten Tabellen; x/y-Spalten, escaped Beschriftungen, nebeneinander skalierte Blöcke. Das Zieldokument benötigt `graphicx`.
- PDF/Druck: ausgewählte Tabellen nebeneinander, individuelle proportionale Skalierung und mehrseitige Tabellen. Berichtstabellen und TSV-Export enthalten nur x/y.
- Sichere arithmetische Zellrechnungen mit `=` und Umrechnungsassistent: einmalig, auf ausgewählte Zellen oder automatisch pro Tabelle. Rohwerte und Formeln bleiben in PPN und Projekten erhalten. Interne Zwischenablage erhält Rohwerte zur Vermeidung doppelter Umrechnung.
- `.ppproj` speichert alle Datensätze des aktuellen Fensters, Messreihen, Optionen, Metadaten und Tabellenauswahl. Öffnen ergänzt die vorhandenen Datensätze; ungültige Dateien werden ohne Teilübernahme abgewiesen. Ergebnisse werden neu berechnet.

## Ausgeführte Prüfungen

`native/scripts/build-local.sh` sowie abschließender Neuaufbau der Anwendung: erfolgreich.
`native/scripts/test.sh`: erfolgreich, Ausgabe `/tmp/physpract-full-tests.log`, Prüfdaten `/tmp/physpract-tests.IKcNR3`.

- 59 Formelprüfungen, einschließlich Syntax, Priorität, wissenschaftlicher Schreibweise, Dezimalkomma, Domainfehlern, nicht endlichen Werten und begrenzter Rekursion.
- 448 Backend-Integrationsprüfungen, einschließlich Zellrechnungen, atomarer Umrechnung, Rohwertbearbeitung, internem Kopieren/Einfügen, Rückgängig, M6-Zweittabelle und Projekt-/PPN-Roundtrips.
- 120 unabhängige PDF-Prüfungen mit Poppler: x/y-Spalten, Zahlengenauigkeit, Fortsetzungsseiten, Druckbereiche und nebeneinander angeordnete Tabellen.
- Vorhandene wissenschaftliche Tests, 51 unabhängige Referenzvergleiche, Zellbereichs- und FKS-Tests erfolgreich.
- QML-Layout-/Tastaturtests: linear 48, nonlinear 33, spline 32, M6 21, O1 33 Prüfungen; Mehrfenstertest erfolgreich.
- Separater QML-Aufruf mit `--ui-smoke /tmp/physpract-conversion.png --module linear --check-conversion`: erfolgreich. Dialog und gerenderte PDF-Seite visuell geprüft.

Die LaTeX-Ausgabe wurde strukturell geprüft, nicht mit einer TeX-Installation kompiliert. Dieser Implementierungsprüflauf umfasste noch kein Debian-Paket. Den anschließenden Paketstand dokumentiert [TESTERGEBNISSE-0.8.0.txt](../TESTERGEBNISSE-0.8.0.txt).
