# Implementierungs- und Prüfstand

Stand: 30.10.2026. Quellstand **0.8.0** für Debian 13 (trixie), amd64.
Die [Funktionsabnahme](FUNKTIONSABNAHME.md) definiert den Umfang und die Freigabekriterien.
Maßgeblich sind verlässliche physikalische Auswertungen und vollständige native Arbeitsabläufe.
Fehler, Rundungsverluste und instabile Startwertsuche des Windows-Originals werden nicht nachgebildet.
Originaltests klären bei Bedarf einzelne Funktionsfragen; offene Originalforensik ist kein zusätzliches Freigabetor.

## Tabellen und Projekte in 0.8.0

Der aktuelle Quellstand enthält sämtliche bisherigen Funktionen sowie LaTeX-Tabellenexport,
nebeneinander skalierte x/y-Berichtstabellen, x/y-Texttabellenexport, sichere Zellrechnungen,
einmalige und automatische Formelumrechnung mit Rohwerterhalt und vollständige `.ppproj`-Projekte.
PPN bleibt Version 2; das Projektformat verwendet Version 1. Aktive automatische Umrechnung
benötigt PPN oder ein Projekt; FKS kann die zusätzlichen Rohwerte/Formeln nicht erhalten.

Aktuelle Prüfungen und Paketgrenzen: [TESTERGEBNISSE-0.8.0.txt](TESTERGEBNISSE-0.8.0.txt).
Paketinhalt, Binäridentität und Prüfsummen wurden geprüft. Installation, fünf Moduloberflächen,
Entfernung und Neuinstallation des 0.8.0-Pakets haben in der isolierten Debian-13-Testumgebung
bestanden; eigene Dokumente blieben bytegleich erhalten. Der Host-Paketbestand blieb unverändert.
Frühere Installationsnachweise gelten ausschließlich für die dort genannte Paketversion.

## Zusätzliche Fenster in 0.7.1

Das Menü **Fenster → Datensätze in neuem Fenster öffnen …** bietet eine Mehrfachauswahl
aller geöffneten Datensätze. Die Auswahl wird als unabhängige Kopien in einem zusätzlichen
Fenster geöffnet. Alle Messreihen, ungespeicherten Eingaben, Metadaten, Optionen und
vorhandenen Berechnungsergebnisse bleiben erhalten. Die Kopien haben eigene Speicherpfade.
Weitere Fenster können auch aus zusätzlichen Fenstern geöffnet werden. Die gemeinsame
Wiederherstellung berücksichtigt die ungespeicherten Dokumente aller Fenster.

Die Prüfbelege für 0.7.1 stehen in [TESTERGEBNISSE-0.7.1.txt](TESTERGEBNISSE-0.7.1.txt).

## FKS-Austausch in 0.7.0

Bestehende FKS-Dokumente lassen sich öffnen, in Tabellen und zugeordneten Metadaten/Optionen
ändern und im Originalformat speichern. Mehrere Messreihen und beide M6-Tabellen werden erhalten.
Unveränderte Archive bleiben bytegenau; unbekannte Felder bleiben erhalten. Unsichere oder nicht
zugeordnete Änderungen werden abgewiesen. Neue Dokumente ohne Originalarchiv und ältere PPN
ohne Vergleichsbasis sind nur als PPN speicherbar.

Die Kompatibilitätsbelege betreffen PhysPract 3.4.7b04. Original-Spline-Dämpfung bleibt als
separater Rohwert erhalten; sie ist nicht die native Dämpfung. Bei O8 wird die feste Dicke im
Original erneut erfragt. Wissenschaftliche Änderungen mit nichtstandardmäßiger fester Dicke
benötigen PPN. Die genauen Grenzen stehen in [DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md).

Build und vollständige Testsuite für 0.7.0 haben bestanden; Einzelzahlen stehen in
[TESTERGEBNISSE-0.7.0.txt](TESTERGEBNISSE-0.7.0.txt). Installation, Start aller fünf Moduloberflächen, Entfernen und Neuinstallation des Debian-Pakets
haben in einer isolierten Debian-13-Umgebung bestanden. Protokolle stehen unter
`testprotokolle/0.7.0/clean-debian/`; Benutzerdokumente blieben bytegleich erhalten. Die nachfolgenden Zahlen und
Paketnachweise gehören ausdrücklich zu 0.6.1 und belegen kein neues Paket.
Die laufenden Quellbelege liegen unter [testprotokolle/0.7.0/](testprotokolle/0.7.0/).

## Historische Korrekturen von 0.6.1

Die ergänzende Fachprüfung der Praktikumsabläufe fand drei Fehlergruppen und führte zu gezielten Korrekturen:
nichtidentifizierbare NLR-Parameter, zeilenabhängige Exponential-Startwerte sowie unvollständige
O1-/M6-Optionsweitergabe in Anzeigeebenen und PDF-Ausgabe. Ein analytischer Jacobian mit
spaltennormierter SVD-Rangprüfung verhindert scheinbar sichere ±0 bei unterbestimmten Fits.
Exponential-Startwerte nutzen die X-Grenzen; das PDF enthält die tatsächlichen Unsicherheiten,
den Fokusmodus, aktive M6-Höhenkorrekturen und zusätzlich das direkte Radienverhältnis.
Die unabhängige Review überprüfte 139 Modellableitungen; fachliche Grenzen stehen in MATHEMATIK.md.

## Verbesserungen von 0.6.0

| Bereich | Ergänzung |
|---|---|
| Orthogonale Regression | Zentrierte und gemeinsam normierte Streuungsrechnung für kleine und große Skalen sowie beide Steigungsvorzeichen |
| Spline | Gemeinsame Hermite-Steigungen für C1-stetige Dämpfung; bei D=1 formtreues PCHIP statt einer Mischung mit geknickter linearer Interpolation |
| O1 | Physikalisches Steigung-1-Modell für festen und angepassten Fokus; Brennweite und Hauptebenenabstand mit Fehlerfortpflanzung durch vollständige Rohwertrefits und drei Rohunsicherheiten |
| M6-Unsicherheiten | Vollständige Korrektur- und Fitkette bei radialer Einzelpunktvariation; sechs Kreisparameter und das korrigierte Massenverhältnis als sieben Unsicherheitsausgaben |
| M6-Auftreffhöhe | Optionale Korrektur mit expliziter Fallhöhe und getrennten Kugelradien; mit der Stoßpunktkorrektur kombinierbar |
| Grafik kopieren | Beschriftete Grafik als Bild in die Zwischenablage; Menü und Strg+G |

Gleichungen, Definitionsbereiche und Unsicherheitsannahmen stehen in [MATHEMATIK.md](MATHEMATIK.md).
Die vorhandenen Auswertungsmodelle, Tabellen, mehrere Messreihen, gemeinsame Grafiken, PNG/PDF/Druck,
Rückgängig, atomisches Speichern und Wiederherstellung gehören weiterhin zum Umfang.

## Historischer Nachweisstatus 0.6.1

Gemeinsamer Build und vollständige Testsuite haben bestanden: 23879 wissenschaftliche Assertions,
130 analytische O1- und 577 M6-Höhenprüfungen, 51 unabhängige NumPy-/SciPy-Vergleiche,
342 Backend-/Datei-/Zwischenablageprüfungen, 116 PDF-/Druckprüfungen und 117 QML-Prüfungen.
Zellbereiche, FKS-Tabellen und unveränderte Originalarchive wurden ebenfalls geprüft.
Ein Review fand doppelte Fehlerskalierung bei der M6-Höhenkorrektur; der abschließende Lauf
enthält die Korrektur und einen analytischen Regressionstest.

Das Debian-Paket wurde in einer isolierten Debian-13-Umgebung installiert, mit allen fünf
Moduloberflächen geprüft, entfernt und neu installiert. Eigene Dokumente blieben bytegleich erhalten;
dpkg meldete vor und nach dem Test keine Paketfehler. Der Host-Paketbestand wurde nicht verändert.
Der native Bedienlauf bestätigt O1-Ergebnisse und Eingabeunsicherheiten, M6-Höhenoptionen sowie
Grafik kopieren über Menü und Strg+G, auch bei ausgewählter Tabellenzelle. Strg+O öffnet den Dateidialog.
Die zunächst fehlgeschlagenen Tastenkürzel nutzten große Buchstaben im Linux-Testtreiber;
mit korrekten Kleinbuchstabenaufrufen bestehen sie ohne Produktänderung.

[TESTERGEBNISSE-0.6.1.txt](TESTERGEBNISSE-0.6.1.txt) fasst die Nachweise zusammen.
Rohlogs, Paketprüfsummen und die genauen isolierten Testaufrufe stehen unter
[testprotokolle/0.6.1/](testprotokolle/0.6.1/). Der [Fachaudit](testprotokolle/fachumfang-audit-2026-10-24.md)
verknüpft Praktikumsquellen, bestätigte Fehler und Korrekturen. Die früheren 0.6.0-Nachweise bleiben erhalten.
Der zusätzliche [native Dateidialog-/Recoverylauf](testprotokolle/funktionsverbesserung-2026-10-24/desktop/dateien-wiederherstellung.json)
bestätigt Speichern/Wiederöffnen und die Wiederherstellung nach gezieltem SIGKILL einer privaten Testinstanz.
Der ungespeicherte Wert 543,21 und die O1-Einstellungen blieben erhalten.
Der native Druckdialog erzeugte eine einseitige PDF-Datei; Messwerte, Ergebnisse und tatsächliche
O1-Eingabeunsicherheiten wurden unabhängig mit Poppler geprüft. PDF und Screenshot liegen unter
[testprotokolle/0.6.1/desktop/](testprotokolle/0.6.1/desktop/). Physische Drucker wurden nicht verwendet.
Dies bestätigt die native Debian-Ausgabe im beschriebenen Umfang; eine öffentliche Lizenzfreigabe
oder Android-Abnahme ist damit nicht verbunden.

## Dateiaustausch und Grenzen

PPN ist das eigene vollständige Dokumentformat. Es erhält Messreihen, Rechenoptionen, Metadaten,
Aktiv-/Fehlerbalkenflags, Eingabepräzision und gespeicherte Spline-Verarbeitungsschritte.
Ergebnisse werden nach dem Öffnen neu berechnet. Einzelheiten stehen in [PPN-FORMAT.md](PPN-FORMAT.md).

FKS wird in 0.7.0 quelltreu aus bestehenden Originalarchiven geschrieben; Voraussetzung sind
Originalbytes und Vergleichsbasis. Umfang und sichere Rückexportgrenzen stehen in
[DATEIAUSTAUSCH.md](DATEIAUSTAUSCH.md). Die alte Hauptdateiverwaltung ist nicht vorhanden.

Geräteanbindung und alte Hauptdateiverwaltung bleiben ausgeschlossen. Android folgt nach der
Debian-Funktionsabnahme; ein Android-Paket wurde nicht gebaut. Die Projektlizenz ist weiterhin offen.

## Erhalt und Verlauf

Der bisherige Status wurde vor dieser Neufassung bytegleich unter
[STATUS-vor-0.6.0.md](../archiv/2026-10-24/STATUS-vor-0.6.0.md) archiviert.
Die [zugehörige SHA-256-Datei](../archiv/2026-10-24/STATUS-vor-0.6.0.sha256) sichert seine Identität.
Quellsicherungen, Originalarchive, ältere Pakete sowie sämtliche 0.5.0- und Originalprotokolle bleiben erhalten.
Die [0.5.0-Testergebnisse](TESTERGEBNISSE-0.5.0.txt) und
[saubere Debian-Paketprüfung von 0.5.0](testprotokolle/0.5.0/clean-debian/) sind historische Nachweise.
[VERLAUF.md](../VERLAUF.md) dokumentiert die Richtungsänderung und die bisherigen Arbeiten.
