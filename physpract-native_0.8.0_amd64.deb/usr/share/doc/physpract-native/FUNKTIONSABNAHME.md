# Funktionsabnahme statt Fehlernachbildung

Maßstab seit dem Nutzerauftrag vom 24.10.2026: vollständige Auswertungsfunktionen mit nachvollziehbarer,
mathematisch verlässlicher Berechnung. Fehler, Rundungsverluste, instabile Startwertsuche und die genaue
Bildschirmdarstellung des Windows-Originals werden nicht nachgebaut. Originaltests dienen nur noch dazu,
eine konkrete Funktionsfrage zu klären. Vorhandene Vergleichsdaten bleiben als historische Belege erhalten.

## Umfang

- Lineare Regression: allgemeine, Ursprungs- und orthogonale Gerade, Residuen und Standardunsicherheiten.
- Nichtlineare Regression: Parabel mit beiden Darstellungen, Exponentialfunktion, Hyperbel, Logarithmus,
  Tangens und O8 einschließlich vorhandener Offset-, Dicken- und Winkeloptionen.
- Splines: kubische Interpolation, stetig differenzierbare Dämpfung, acht Glättungen und Digitalisierung.
- O1: fester und angepasster Fokus, Brennweite, Hauptebenenabstand und gemeinsame Fehlerfortpflanzung.
- M6: zwei Kreisfits, Stoßpunkt- und optionale Auftreffhöhenkorrektur, Massenverhältnisse und Unsicherheiten.
- Tabellen, mehrere Messreihen, gemeinsame Grafiken, Beschriftungen, Zwischenablage, PNG/PDF/Druck,
  natives Speichern, Rückgängig und Wiederherstellung.

Geräteanbindung und alte Hauptdateiverwaltung bleiben wie zuvor ausgeschlossen. Android folgt nach der
Debian-Funktionsabnahme. Das eigene PPN-Format erhält Messreihen, Optionen und die Eingabepräzision;
es bleibt das vollständige native Format. 0.7.0 ergänzt den quelltreuen Rückexport bestehender
FKS-Dokumente: Tabellen, zugeordnete Metadaten/Optionen, mehrere Reihen und M6-Doppeltabellen.
Unveränderte Archive bleiben bytegenau; unbekannte Felder bleiben erhalten. Nicht zugeordnete
Änderungen werden vor dem Schreiben abgewiesen. Ohne Originalarchiv und Vergleichsbasis kein
FKS-Export. Belegt ist Original 3.4.7b04; Grenzen für Spline und O8 stehen im
[Dateiaustausch](DATEIAUSTAUSCH.md).

## Gezielte Verbesserungen

| Lücke | Neue Lösung | Erforderlicher Nachweis |
|---|---|---|
| Orthogonaler Fit scheitert an kleinen Skalen | Zentrierte, gemeinsam normierte Streuungsrechnung | Unabhängige SVD-Referenz bei kleinen/großen Skalen und beiden Steigungsvorzeichen |
| Gedämpfter Spline besitzt Knicke | Gemeinsame Hermite-Steigungen; Übergang vom natürlichen Spline zu formtreuem PCHIP | Knotentreue, C1-Stetigkeit, analytische Referenzen und keine zusätzlichen Überschwinger bei D=1 |
| O1-Ableitungen und ihre Fehler fehlen | Physikalisches Steigung-1-Modell; vollständige Rohwertrefits mit gemeinsamem Fokusfehler | Analytische Sensitivitäten einschließlich Kovarianz, beide Fokusmodi und sichtbare Ergebnisse |
| M6-Fehler halten Korrekturen fest und lassen μ aus | Erneute vollständige Korrektur-/Fitkette für jede radiale Eingabevariation | Analytische μ-Kovarianz und unabhängige numerische Refits |
| Auftreffhöhenkorrektur fehlt | Explizite Fallhöhe; getrennte Kugelradien; Kombination mit Stoßpunktkorrektur | Unabhängig vorwärts erzeugte Koordinaten, Translation und physikalische Grenzfälle |
| Grafik kopieren fehlt | Beschriftete Grafik als Bild, Menü und Strg+G | Zwischenablage enthält gezeichnete Daten; Dokument bleibt unverändert |

Die Verbesserungen von 0.6.0 und 0.6.1 bestehen den gemeinsamen Build, wissenschaftliche Tests, Backend-/Datei-/PDF-Prüfungen
und den nativen Bedienlauf. Der isolierte Debian-Paketlebenszyklus besteht ebenfalls.
Einzelnachweise und Grenzen stehen in [STATUS.md](STATUS.md) und [TESTERGEBNISSE-0.6.1.txt](TESTERGEBNISSE-0.6.1.txt).
Die ergänzende Fachprüfung von 0.6.1 korrigiert nichtidentifizierbare nichtlineare Fits,
Exponential-Startwerte und die PDF-Weitergabe neuer Optionen. Recovery und nativer PDF-Druck
sind zusätzlich direkt geprüft; physische Drucker und Android sind nicht Teil dieses Nachweises.
Neue mathematische Definitionen und Unsicherheitsannahmen stehen in [MATHEMATIK.md](MATHEMATIK.md).
Historische Originalparität ist kein zusätzliches Freigabetor.

## Verlauf und Erhalt

Vor den Änderungen wurden betroffene Kernquellen unter
`archiv/2026-10-24/native-vor-funktionsverbesserung/` gesichert. Originalarchive, Referenzprotokolle und
ältere Pakete bleiben erhalten. Der [Projektverlauf](../VERLAUF.md) hält die Richtungsänderung fest.
